-- MySQL dump 10.13  Distrib 5.6.19, for Win32 (x86)
--
-- Host: localhost    Database: tbxt
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_account`
--

DROP TABLE IF EXISTS `t_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `is_admin` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`code`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_account`
--

LOCK TABLES `t_account` WRITE;
/*!40000 ALTER TABLE `t_account` DISABLE KEYS */;
INSERT INTO `t_account` VALUES (1,'admin','admin','教育局管理员','',1),(8,'test','test','华迪信息学校',NULL,0);
/*!40000 ALTER TABLE `t_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_b_bxtj`
--

DROP TABLE IF EXISTS `t_b_bxtj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_b_bxtj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area` float DEFAULT '0' COMMENT '占地面积',
  `area_own` float DEFAULT '0' COMMENT '自有产权占地面积',
  `area_primary` float DEFAULT '0' COMMENT '主校区自有占地面积',
  `area_rent` int(11) DEFAULT '0' COMMENT '租用校区剩余租用年限',
  `building_area` float DEFAULT '0' COMMENT '总建筑面积',
  `building_area_own` float DEFAULT '0' COMMENT '学校自有产权建筑面积',
  `building_area_primary` float DEFAULT '0' COMMENT '主校区自有产权建筑面积',
  `building_area_rent` int(11) DEFAULT '0' COMMENT '租用建筑的剩余租用年限',
  `classrooms` int(11) DEFAULT '0' COMMENT '理论课教室数',
  `classrooms_practice` int(11) DEFAULT '0' COMMENT '理实一体教室数',
  `beds` int(11) DEFAULT '0' COMMENT '住宿床位数',
  `food_seats` int(11) DEFAULT '0' COMMENT '学生用餐座位数',
  `library_books` int(11) DEFAULT '0' COMMENT '图书馆藏书数量',
  `electronic_books` int(11) DEFAULT '0' COMMENT '电子读物数量',
  `newspapaer_count` int(11) DEFAULT '0' COMMENT '报纸订阅数',
  `magazine_count` int(11) DEFAULT '0' COMMENT '期刊订阅数',
  `reading_room_seats` int(11) DEFAULT '0' COMMENT '阅览室座位数',
  `electronic_seats` int(11) DEFAULT '0' COMMENT '电子阅览室座位数',
  `teacher_computers` int(11) DEFAULT '0' COMMENT '教师用台式机数量',
  `teacher_laptop` int(11) DEFAULT '0' COMMENT '教师用笔记本数量',
  `budget_funds` float DEFAULT '0' COMMENT '地方生均预算内拨款标准',
  `finance_funds` float DEFAULT '0' COMMENT '地方财政专项拨款',
  `debt` float DEFAULT '0' COMMENT '负债总额',
  `loan` float DEFAULT '0' COMMENT '货款总额',
  `device_funds` float DEFAULT '0' COMMENT '教学仪器设备总值',
  `device_count` int(11) DEFAULT '0' COMMENT '教学仪器设备总量',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4bxtj_idx` (`account_id`),
  CONSTRAINT `account_id4bxtj` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_b_bxtj`
--

LOCK TABLES `t_b_bxtj` WRITE;
/*!40000 ALTER TABLE `t_b_bxtj` DISABLE KEYS */;
INSERT INTO `t_b_bxtj` VALUES (12,1213.12,0,222,0,555,0,5555,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `t_b_bxtj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_b_gjhz`
--

DROP TABLE IF EXISTS `t_b_gjhz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_b_gjhz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profession_coop_count` int(11) DEFAULT '0' COMMENT '合作专业数',
  `profession_coop_course` int(11) DEFAULT '0' COMMENT '合作课程数',
  `student_total` int(11) DEFAULT '0' COMMENT '培养学生数',
  `write_books` int(11) DEFAULT '0' COMMENT '开发教材数',
  `international_contests` int(11) DEFAULT '0' COMMENT '国际技能大赛获奖数',
  `foreign_students` int(11) DEFAULT '0' COMMENT '接受外籍学生数',
  `abroad_students` int(11) DEFAULT '0' COMMENT '出国就业学生数',
  `foreign_course` int(11) DEFAULT '0' COMMENT '引进国外课程数',
  `international_certs` int(11) DEFAULT '0' COMMENT '引进国际证书数',
  `foreign_teachers` int(11) DEFAULT '0' COMMENT '聘任外教数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4icoop_idx` (`account_id`),
  CONSTRAINT `account_id4icoop` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_b_gjhz`
--

LOCK TABLES `t_b_gjhz` WRITE;
/*!40000 ALTER TABLE `t_b_gjhz` DISABLE KEYS */;
INSERT INTO `t_b_gjhz` VALUES (1,111,2222,555,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `t_b_gjhz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_b_xqhz`
--

DROP TABLE IF EXISTS `t_b_xqhz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_b_xqhz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `practice_count` int(11) DEFAULT '0' COMMENT '校外实训基地数',
  `coop_enterprise_count` int(11) DEFAULT '0' COMMENT '签订合作协议的企业数',
  `coop_profession_count` int(11) DEFAULT '0' COMMENT '签订合作协议的专业数',
  `coop_ent_pro_count` int(11) DEFAULT '0' COMMENT '合作企业参与教学的专业数',
  `coop_ent_pro_teacher_count` int(11) DEFAULT '0' COMMENT '合作企业参与教学教师数',
  `coop_course_count` int(11) DEFAULT '0' COMMENT '合作企业参与教学课时数',
  `coop_ent_funds` int(11) DEFAULT '0' COMMENT '合作企业投入资金总额',
  `coop_ent_into_funds` int(11) DEFAULT '0' COMMENT '合作企业投入到帐资金',
  `coop_ent_device` int(11) DEFAULT '0' COMMENT '合作企业投入设备总值',
  `coop_ent_practice_students` int(11) DEFAULT '0' COMMENT '合作企业接受实训学生数（人月）',
  `coop_ent_practice2_students` int(11) DEFAULT '0' COMMENT '合作企业接受学生顶岗实习学生数',
  `coop_ent_occu_students` int(11) DEFAULT '0' COMMENT '合作企业接受就业学生数',
  `rd_with_ent_count` int(11) DEFAULT '0' COMMENT '与企业共建研发中心数',
  `outer_teacher_base_count` int(11) DEFAULT '0' COMMENT '校外教师培训基地数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4xqhz_idx` (`account_id`),
  CONSTRAINT `account_id4xqhz` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_b_xqhz`
--

LOCK TABLES `t_b_xqhz` WRITE;
/*!40000 ALTER TABLE `t_b_xqhz` DISABLE KEYS */;
INSERT INTO `t_b_xqhz` VALUES (1,1,111,0,2222,0,555,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `t_b_xqhz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_b_zjcyxx`
--

DROP TABLE IF EXISTS `t_b_zjcyxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_b_zjcyxx` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leader_count` int(11) DEFAULT '0' COMMENT '本校牵牛组织的职教集团数',
  `leader_enterprise_count` int(11) DEFAULT '0' COMMENT '参加本校牵头的职教集团企业数',
  `leader_school_count` int(11) DEFAULT '0' COMMENT '参加本校牵头的职教集团学校数',
  `leader_profession_count` int(11) DEFAULT '0' COMMENT '参加本校牵头的职教集团的专业数',
  `join_count` int(11) DEFAULT '0' COMMENT '本校参与的职教集团数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4zjcyxx_idx` (`account_id`),
  CONSTRAINT `account_id4zjcyxx` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_b_zjcyxx`
--

LOCK TABLES `t_b_zjcyxx` WRITE;
/*!40000 ALTER TABLE `t_b_zjcyxx` DISABLE KEYS */;
INSERT INTO `t_b_zjcyxx` VALUES (1,222222,555,0,0,0,1);
/*!40000 ALTER TABLE `t_b_zjcyxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_b_zykcjs`
--

DROP TABLE IF EXISTS `t_b_zykcjs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_b_zykcjs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profession_category` int(11) DEFAULT '0' COMMENT '专业大类数',
  `profession_count` int(11) DEFAULT '0' COMMENT '专业数',
  `profession_aspects` int(11) DEFAULT '0' COMMENT '专业方向数',
  `profession_leaders` int(11) DEFAULT '0' COMMENT '省部级以上示范（重点、骨干、特色）专业数',
  `profession_contest` int(11) DEFAULT '0' COMMENT '学校开展技能大赛的专业数',
  `profession_double` int(11) DEFAULT '0' COMMENT '双证书专业数',
  `profession_project` int(11) DEFAULT '0' COMMENT '实现项目教学的专业课程数',
  `profession_enterprise` int(11) DEFAULT '0' COMMENT '企业参与开发的专业课程数',
  `teacher_public_books` int(11) DEFAULT '0' COMMENT '校本教材数',
  `teacher_books` int(11) DEFAULT '0' COMMENT '教师主编并公开出版的教材数',
  `share_books` int(11) DEFAULT '0' COMMENT '牵头开发国家共建共享计划课程数',
  `share_nation_books` int(11) DEFAULT '0' COMMENT '参与开发国家共建共享课程数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4pc_idx` (`account_id`),
  CONSTRAINT `account_id4pc` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_b_zykcjs`
--

LOCK TABLES `t_b_zykcjs` WRITE;
/*!40000 ALTER TABLE `t_b_zykcjs` DISABLE KEYS */;
INSERT INTO `t_b_zykcjs` VALUES (1,11111,0,555,0,0,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `t_b_zykcjs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_course`
--

DROP TABLE IF EXISTS `t_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_course`
--

LOCK TABLES `t_course` WRITE;
/*!40000 ALTER TABLE `t_course` DISABLE KEYS */;
INSERT INTO `t_course` VALUES (18,'语文',1),(19,'数学',1),(20,'化学',1),(21,'英语',1),(22,'啊啊',1),(25,'66',1),(26,'JAV',2),(27,' 软件开发',2),(28,'2007级',3),(29,'2014级',3),(30,'7',1);
/*!40000 ALTER TABLE `t_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_major`
--

DROP TABLE IF EXISTS `t_major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_major` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_major`
--

LOCK TABLES `t_major` WRITE;
/*!40000 ALTER TABLE `t_major` DISABLE KEYS */;
INSERT INTO `t_major` VALUES (1,0,'专业大类测试');
/*!40000 ALTER TABLE `t_major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pxs`
--

DROP TABLE IF EXISTS `t_pxs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lexing` int(11) DEFAULT NULL COMMENT '培训室类型',
  `zhuanye` int(11) DEFAULT NULL COMMENT '专业',
  `shixunjidi` varchar(45) DEFAULT NULL COMMENT '实训基地名称',
  `shixunshi` varchar(45) DEFAULT NULL COMMENT '实训室名称',
  `taoshu_count` int(11) DEFAULT '0' COMMENT '实训室内设施设备台套数',
  `zongzhi_count` int(11) DEFAULT '0' COMMENT '设施设备总值',
  `gongwei_count` int(11) DEFAULT '0' COMMENT '工位数',
  `kecheng` varchar(45) DEFAULT NULL COMMENT '对外开放课程名称',
  `kecheng_count` int(11) DEFAULT '0' COMMENT '课程数',
  `keshi_count` int(11) DEFAULT '0' COMMENT '课时数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pxs`
--

LOCK TABLES `t_pxs` WRITE;
/*!40000 ALTER TABLE `t_pxs` DISABLE KEYS */;
INSERT INTO `t_pxs` VALUES (1,1,18,'14','22',3,99,77,NULL,0,0,1),(2,1,20,'1','1',1,1,1,NULL,0,0,1),(4,2,18,',','',0,0,0,'44',444,4444,1),(5,1,22,'9,','9',9,0,0,'',0,0,1),(14,1,19,'1','1',1,1,1,NULL,0,0,1),(15,3,18,'1',NULL,0,0,0,NULL,0,0,1),(16,1,26,'1','1',1,1,1,NULL,0,0,1);
/*!40000 ALTER TABLE `t_pxs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_s_xsqk`
--

DROP TABLE IF EXISTS `t_s_xsqk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_s_xsqk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cprofessional` int(11) DEFAULT NULL COMMENT '专业',
  `cgrade` int(11) DEFAULT NULL COMMENT '年级',
  `studentofnum` int(11) DEFAULT NULL COMMENT '学生人数',
  `classesofnum` int(11) DEFAULT NULL COMMENT '班级数',
  `lossofnum` int(11) DEFAULT NULL COMMENT '流失学生数',
  `graduatestwocard` int(11) DEFAULT NULL COMMENT '毕业生双证率',
  `nationalnumber` int(11) DEFAULT NULL COMMENT '在国家级职业技能大赛获奖数',
  `provincialnumber` int(11) DEFAULT NULL COMMENT '在省部级职业技能大赛获奖数',
  `municipalnumber` int(11) DEFAULT NULL COMMENT '在地市级职业技能大赛获奖数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_s_xsqk`
--

LOCK TABLES `t_s_xsqk` WRITE;
/*!40000 ALTER TABLE `t_s_xsqk` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_s_xsqk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_s_zypxqk`
--

DROP TABLE IF EXISTS `t_s_zypxqk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_s_zypxqk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_persons` int(11) DEFAULT '0' COMMENT '培训企业员工规模',
  `community_days` int(11) DEFAULT '0' COMMENT '面向社区开放学校资源天数',
  `services_persons` int(11) DEFAULT '0' COMMENT '学校服务社区的人天数',
  `tranning_persons` int(11) DEFAULT '0' COMMENT '培训社区居民数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id4zypxqk_idx` (`account_id`),
  CONSTRAINT `account_id4zypxqk` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_s_zypxqk`
--

LOCK TABLES `t_s_zypxqk` WRITE;
/*!40000 ALTER TABLE `t_s_zypxqk` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_s_zypxqk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sxjd`
--

DROP TABLE IF EXISTS `t_sxjd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_sxjd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sxjd`
--

LOCK TABLES `t_sxjd` WRITE;
/*!40000 ALTER TABLE `t_sxjd` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sxjd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_t_classhour`
--

DROP TABLE IF EXISTS `t_t_classhour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_t_classhour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `professional` int(11) DEFAULT NULL COMMENT '专业',
  `grade` int(11) DEFAULT NULL COMMENT '年级',
  `course_name` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '课程名称',
  `opening_period` int(11) DEFAULT NULL COMMENT '开设期数',
  `r_openingperiod` int(11) DEFAULT NULL COMMENT '修订开设期数',
  `class_number` int(11) DEFAULT NULL COMMENT '每期课时数',
  `r_classnumber` int(11) DEFAULT NULL COMMENT '修订每期课时数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_t_classhour`
--

LOCK TABLES `t_t_classhour` WRITE;
/*!40000 ALTER TABLE `t_t_classhour` DISABLE KEYS */;
INSERT INTO `t_t_classhour` VALUES (2,0,0,'数学',2,2,4,2,1),(8,0,0,'qwe',5,0,3,0,1),(9,0,0,'fhd',34,0,1,0,1),(10,0,0,'语文',5,0,7,0,1),(11,0,0,'haha',2,0,4,0,1),(12,0,0,'fg',3,0,5,0,1),(13,0,0,'物理',5,0,2,0,1);
/*!40000 ALTER TABLE `t_t_classhour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_t_ggk`
--

DROP TABLE IF EXISTS `t_t_ggk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_t_ggk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `leader_count` int(11) DEFAULT '0' COMMENT '校级以上专业带头人数',
  `advance_count` int(11) DEFAULT '0' COMMENT '高级职称教师数',
  `major_count` int(11) DEFAULT '0' COMMENT '骨干教师数',
  `double_count` int(11) DEFAULT '0' COMMENT '双师型教师数',
  `benke_count` int(11) DEFAULT '0' COMMENT '本科及以上学历专业任教师数',
  `yanjiusheng_count` int(11) DEFAULT '0' COMMENT '具有研究生学历或学位的专任教师数',
  `shengji_count` int(11) DEFAULT '0' COMMENT '参加省级以下培训专任教师数',
  `shengji2_count` int(11) DEFAULT '0' COMMENT '参加省级以上培训专任教师数',
  `guojia_count` int(11) DEFAULT '0' COMMENT '参加国家级培训专任教师数',
  `guoji_count` int(11) DEFAULT '0' COMMENT '参加国外培训专任教师数',
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_course_unique` (`course_id`,`account_id`),
  KEY `account_id4gkk_idx` (`account_id`),
  CONSTRAINT `account_id4gkk` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_t_ggk`
--

LOCK TABLES `t_t_ggk` WRITE;
/*!40000 ALTER TABLE `t_t_ggk` DISABLE KEYS */;
INSERT INTO `t_t_ggk` VALUES (7,20,113,2,1,1,1,23,1111,5,11111,8,1),(11,19,7,2,8,2,1,2,1,22220,1,20,1),(12,21,2,6,3,6,9,6,7,6,5,6,1),(13,18,4,1,4,1,4,1,4,1,4,1,1),(14,25,66,0,0,0,0,0,0,0,0,0,1),(15,-1,0,0,0,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `t_t_ggk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_t_jbqk`
--

DROP TABLE IF EXISTS `t_t_jbqk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_t_jbqk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_total` int(11) DEFAULT '0' COMMENT '教职工总数',
  `teacher_in_total` int(11) DEFAULT '0' COMMENT '在编在职教职工数',
  `teacher_regs` int(11) DEFAULT '0' COMMENT '教职工编制数',
  `teacher_ins` int(11) DEFAULT '0' COMMENT '专任教师数',
  `teacher_outs` int(11) DEFAULT '0' COMMENT '外聘教师数',
  `account_id` int(11) DEFAULT NULL,
  `file_name_path` varchar(75) DEFAULT NULL COMMENT '上传路径',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `account_id4jbqk_idx` (`account_id`),
  CONSTRAINT `account_id4jbqk` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_t_jbqk`
--

LOCK TABLES `t_t_jbqk` WRITE;
/*!40000 ALTER TABLE `t_t_jbqk` DISABLE KEYS */;
INSERT INTO `t_t_jbqk` VALUES (1,55,5,5,6,6,1,NULL);
/*!40000 ALTER TABLE `t_t_jbqk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_t_jxjh`
--

DROP TABLE IF EXISTS `t_t_jxjh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_t_jxjh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `professional` int(11) DEFAULT NULL COMMENT '专业',
  `grade` int(11) DEFAULT NULL COMMENT '年级',
  `file_name` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '专业教学计划（上传文档）',
  `course_type` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '课程类型（理论或实训）',
  `training_room` int(11) DEFAULT NULL COMMENT '实训室使用（选择相应的实训室）',
  `out_schooltrain` int(11) DEFAULT NULL COMMENT '校外实训选择实训基地',
  `account_id` int(11) DEFAULT NULL,
  `file_name_path` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_t_jxjh`
--

LOCK TABLES `t_t_jxjh` WRITE;
/*!40000 ALTER TABLE `t_t_jxjh` DISABLE KEYS */;
INSERT INTO `t_t_jxjh` VALUES (1,0,0,NULL,'实训',1,1,0,NULL);
/*!40000 ALTER TABLE `t_t_jxjh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_t_zydl`
--

DROP TABLE IF EXISTS `t_t_zydl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_t_zydl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `major_id` int(11) DEFAULT '0' COMMENT '专业大类id',
  `professional` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '主打专业',
  `jiaoshishu_count` int(11) DEFAULT '0' COMMENT '教师数',
  `daitouren_count` int(11) DEFAULT '0' COMMENT '校级以上专业带头人数',
  `zhicheng_count` int(11) DEFAULT '0' COMMENT '中高职称数',
  `shuangshixing_count` int(11) DEFAULT '0' COMMENT '双师型教师数',
  `gugan_count` int(11) DEFAULT '0' COMMENT '骨干教师数',
  `yanjiusheng_count` int(11) DEFAULT '0' COMMENT '具有研究生学历或学位的专任教师数',
  `benke_count` int(11) DEFAULT '0' COMMENT '本科及以上学历专任教师数',
  `shenjiyishang_count` int(11) DEFAULT '0' COMMENT '参加省级以上培训专任教师数',
  `shenjiyixia_count` int(11) DEFAULT '0' COMMENT '参加省级以下培训专任教师数',
  `guowai_count` int(11) DEFAULT '0' COMMENT '参加国外培训专任教师数',
  `guojia_count` int(11) DEFAULT '0' COMMENT '参加国家级培训专任教师数',
  `account_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `account_id_zydl_idx` (`account_id`),
  CONSTRAINT `account_id_zydl` FOREIGN KEY (`account_id`) REFERENCES `t_account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_t_zydl`
--

LOCK TABLES `t_t_zydl` WRITE;
/*!40000 ALTER TABLE `t_t_zydl` DISABLE KEYS */;
INSERT INTO `t_t_zydl` VALUES (2,18,'1111',1,1,0,0,0,0,0,0,0,0,0,1),(3,19,'333',1,2,0,3,0,4,0,5,0,6,0,1),(4,27,'1',1,1,1,1,0,1,0,0,0,0,0,1),(5,26,'111',2,2,0,666,0,777,0,89999,0,0,0,1);
/*!40000 ALTER TABLE `t_t_zydl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-03 13:29:26
