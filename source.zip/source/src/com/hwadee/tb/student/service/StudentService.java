package com.hwadee.tb.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.student.domain.Major;
import com.hwadee.tb.student.domain.Situation;
import com.hwadee.tb.student.domain.Student;
import com.hwadee.tb.student.persistence.StudentMapper;

@Service
public class StudentService {

	@Autowired
	private StudentMapper studentMapper;
	
	public void insertStudent(Student student){
		studentMapper.insertStudent(student);
	}
	
	public void updateStudent(Student student){
		studentMapper.updateStudent(student);
	}
	
	public Student getStudentByAccountId(int accountId){
		 return studentMapper.getStudentByAccountId(accountId);
	}
	
	
	public void insertSituation(Situation situation){
		studentMapper.insertSituation(situation);
	}
	public void updateSituation(Situation situation){
		studentMapper.updateSituation(situation);
	}
	
	public Situation getSituationByAccountId(int accountId){
		return studentMapper.getSituationByAccountId(accountId);
	}
	
	public void insertMajor(Major major){
		studentMapper.insertMajor(major);
	}
	
	public void updateMajor(Major major){
		studentMapper.updateMajor(major);
	}
	
	public List<Major> getMajorlist(int parentid){
		return studentMapper.getMajorlist(parentid);
	}
	
	public Major getMajorByid(int id){
		return studentMapper.getMajorByid(id);
	}
	
	public void deleteMajor(int id){
		studentMapper.deleteMajor(id);
	}
	
}
