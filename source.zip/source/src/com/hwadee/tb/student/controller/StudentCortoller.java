package com.hwadee.tb.student.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.student.domain.Major;
import com.hwadee.tb.student.domain.Situation;
import com.hwadee.tb.student.domain.Student;
import com.hwadee.tb.student.service.StudentService;
import com.hwadee.tb.teacher.domain.Course;
import com.hwadee.tb.teacher.service.TeacherService;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
@RequestMapping("student")
public class StudentCortoller extends AbstractController{
	
		// 日志
		private static Log log = LogFactory.getLog(StudentCortoller.class);
		
		private static final String STUDENT_VIEW = "student/situationofoccupation";
		
		private static final String Situation_VIEW = "student/situation";
		
		@Resource(name="studentService")
		private StudentService studentService;
		
		@Resource(name="teacherService")
		private TeacherService teacherService;
		
		@RequestMapping(method=RequestMethod.GET, value="situationofoccupation")
		ModelAndView situationofoccupation(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session) {
			ModelAndView mav = init(T, STUDENT_VIEW);
			
			boolean isreadonly=false;
			boolean isNew = false;
			
			Account account = (Account) session.getAttribute("account");
			Student student = studentService.getStudentByAccountId(account.getId());
			if (null == student) {
				student = new Student();
				student.setAccount_id(account.getId());
				
				isNew = true;
			}
			else {
				isreadonly = true;
			}
			
			log.debug(student);
			
			mav.addObject("readonly", isreadonly);
			mav.addObject("isNew", isNew);
			mav.addObject("stu", student);
			
			return mav;
		}
		
		
		@RequestMapping(method=RequestMethod.POST, value="situationofoccupation/{action}")
		ModelAndView situationofoccupation_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				@PathVariable String action, @ModelAttribute Student student) {
			ModelAndView mav = init(T, null);
			
			boolean isFailure = false;
			String resultInfo = null;
			String portalname="职业培训情况";
			
			log.debug(student);
			try {
				if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
					studentService.insertStudent(student);
					resultInfo = "写入"+portalname+"成功";
				}
				
				if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
					studentService.updateStudent(student);
					resultInfo = "更新"+portalname+"成功";
				}
			}
			catch(Exception e) {
				e.printStackTrace();
				isFailure = true;
				resultInfo = portalname+"写入或更新失败";
			}
			
			mav.addObject("resultInfo", resultInfo);
			mav.addObject("isFailure", isFailure);
			
			return mav;
		}	
		
		
		@RequestMapping(method=RequestMethod.GET, value="situation")
		ModelAndView situation(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session) {
			ModelAndView mav = init(T, Situation_VIEW);
			
			boolean isreadonly=false;
			boolean isNew = false;
			
			Account account = (Account) session.getAttribute("account");
			Situation situation = studentService.getSituationByAccountId(account.getId());
			if (null == situation) {
				situation = new Situation();
				situation.setAccount_id(account.getId());
				
				isNew = true;
			}
			else {
				isreadonly = true;
			}
			
			log.debug(situation);
			
			mav.addObject("professionallist", studentService.getMajorlist(0));
			mav.addObject("cgradelist", teacherService.getCourseList(3));
			
			mav.addObject("readonly", isreadonly);
			mav.addObject("isNew", isNew);
			mav.addObject("situation", situation);
			
			return mav;
		}
		
		
		@RequestMapping(method=RequestMethod.POST, value="situation/{action}")
		ModelAndView situation_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				@PathVariable String action, @ModelAttribute Situation situation) {
			
			ModelAndView mav = init(T, null);
			
			boolean isFailure = false;
			String resultInfo = null;
			String portalname="学生情况";
			
			log.debug(situation);
			try {
				if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
					studentService.insertSituation(situation);
					resultInfo = "写入"+portalname+"成功";
				}
				
				if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
					studentService.updateSituation(situation);
					resultInfo = "更新"+portalname+"成功";
				}
			}
			catch(Exception e) {
				e.printStackTrace();
				isFailure = true;
				resultInfo = portalname+"写入或更新失败";
			}
			
			mav.addObject("resultInfo", resultInfo);
			mav.addObject("isFailure", isFailure);
			
			return mav;
		}
		
		
		@RequestMapping(method=RequestMethod.GET, value="showaddpro")
		ModelAndView showaddpro(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@RequestParam int typess,@ModelAttribute Course course) {
			String pathview="";
			
			if(typess==1){
				pathview="student/add/addcprofessional";
			}else if(typess==2){
				pathview="student/add/addcgrade";
			}
			ModelAndView mav = init(T, pathview);
			
			if(course.getId()!=0 && typess==2){
				mav.addObject("course", teacherService.getCourseById(course.getId()));
			}else if(typess==1){
				mav.addObject("majorList",studentService.getMajorlist(0));//父节点
			}
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.POST, value="needtoaddpro")
		ModelAndView needtoaddpro(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@ModelAttribute Course course) {
			
			ModelAndView mav = init(T, null);
			
			if(course.getId()==0){
				teacherService.insertCourse(course);
			}else{
				teacherService.updateCourse(course);
			}
			
			mav.addObject("suffinfo", "保存成功");
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.GET, value="cgradeList")
		ModelAndView cgradeList(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@RequestParam int typess,@ModelAttribute  Major major) {
			
			String pathview="";
			if(typess==1){
				pathview="student/add/cprofessionalList";
			}else if(typess==2){
				pathview="student/add/cgradeList";
			}else if(typess==3){
				pathview="student/add/cprofessional2List";
			}
			ModelAndView mav = init(T, pathview);
			
			if(typess==1){
				mav.addObject("majorList",studentService.getMajorlist(0));//父节点
			}else if(typess==2){
				mav.addObject("cgradeList",teacherService.getCourseList(3));
			}else if(typess==3){
				mav.addObject("majorList",studentService.getMajorlist(major.getId()));
			}
			
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.GET, value="delcGrade")
		ModelAndView delcGrade(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@ModelAttribute Course course) {
			
			ModelAndView mav = init(T, "student/add/cgradeList");
			teacherService.deleteCourse(course);
			mav.addObject("cgradeList",teacherService.getCourseList(3));
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.POST, value="needtoaddprot")
		ModelAndView needtoaddprot(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@ModelAttribute Major major) {
			
			ModelAndView mav = init(T, null);
			
			if(major.getId()==0){
					studentService.insertMajor(major);
			}else{
				studentService.updateMajor(major);
			}
			
			mav.addObject("suffinfo", "保存成功");
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.GET, value="showaddprot")
		ModelAndView showaddprot(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@RequestParam int typess,@RequestParam int id) {
			String pathview="";
			
			if(typess==3){
				pathview="student/add/editcprofessional";
			}else if(typess==4){
				pathview=null;
			}
			ModelAndView mav = init(T, pathview);
			
			if(typess==3){
				mav.addObject("major",studentService.getMajorByid(id));//父节点
			}else if(typess==4){
				StringBuffer sb=new StringBuffer();
				List<Major> alist=studentService.getMajorlist(id);
				sb.append("<option value='0'>请选择</option>");
				for(Major major:alist){
					sb.append("<option value='"+major.getId()+"'>"+major.getName()+"</option>");
				}
				System.out.println(sb.toString());
				mav.addObject("majorlist",sb.toString());
			}
				
			return mav;
		}
		
		@RequestMapping(method=RequestMethod.GET, value="delcorifession")
		ModelAndView delcorifession(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
				HttpSession session,@RequestParam int id) {
			
			ModelAndView mav = init(T, "student/add/cprofessionalList");
			studentService.deleteMajor(id);
			mav.addObject("majorList",studentService.getMajorlist(0));//父节点
			return mav;
		}

}
