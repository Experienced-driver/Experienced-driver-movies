package com.hwadee.tb.student.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Major implements Serializable {
	
	private int id;
	
	private int parent_id;
	
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
