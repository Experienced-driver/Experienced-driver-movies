package com.hwadee.tb.student.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Student implements Serializable {
	
	private int id;
	
	private int enterprise_persons; //培训企业员工规模
	
	private int community_days;	//面向社区开放学校资源天数
	
	private int services_persons; //学校服务社区的人天数
	
	private int tranning_persons;	//培训社区居民数
	
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnterprise_persons() {
		return enterprise_persons;
	}

	public void setEnterprise_persons(int enterprise_persons) {
		this.enterprise_persons = enterprise_persons;
	}

	public int getCommunity_days() {
		return community_days;
	}

	public void setCommunity_days(int community_days) {
		this.community_days = community_days;
	}

	public int getServices_persons() {
		return services_persons;
	}

	public void setServices_persons(int services_persons) {
		this.services_persons = services_persons;
	}

	public int getTranning_persons() {
		return tranning_persons;
	}

	public void setTranning_persons(int tranning_persons) {
		this.tranning_persons = tranning_persons;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
