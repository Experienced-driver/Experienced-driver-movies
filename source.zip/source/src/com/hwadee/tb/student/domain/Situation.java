package com.hwadee.tb.student.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Situation implements Serializable {
	
	private int id;
	
	private int cprofessional; //专业
	
	private int cgrade;	//年级
	
	private int studentofnum; //学生人数
	
	private int classesofnum;	//班级数
	
	private int lossofnum;	//流失学生数
	
	private int graduatestwocard;	//毕业生双证率
	
	private int nationalnumber;	//在国家级职业技能大赛获奖数
	
	private int provincialnumber;	//在省部级职业技能大赛获奖数
	
	private int municipalnumber;	//在地市级职业技能大赛获奖数
	
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCprofessional() {
		return cprofessional;
	}

	public void setCprofessional(int cprofessional) {
		this.cprofessional = cprofessional;
	}

	public int getCgrade() {
		return cgrade;
	}

	public void setCgrade(int cgrade) {
		this.cgrade = cgrade;
	}

	public int getStudentofnum() {
		return studentofnum;
	}

	public void setStudentofnum(int studentofnum) {
		this.studentofnum = studentofnum;
	}

	public int getClassesofnum() {
		return classesofnum;
	}

	public void setClassesofnum(int classesofnum) {
		this.classesofnum = classesofnum;
	}

	public int getLossofnum() {
		return lossofnum;
	}

	public void setLossofnum(int lossofnum) {
		this.lossofnum = lossofnum;
	}

	public int getGraduatestwocard() {
		return graduatestwocard;
	}

	public void setGraduatestwocard(int graduatestwocard) {
		this.graduatestwocard = graduatestwocard;
	}

	public int getNationalnumber() {
		return nationalnumber;
	}

	public void setNationalnumber(int nationalnumber) {
		this.nationalnumber = nationalnumber;
	}

	public int getProvincialnumber() {
		return provincialnumber;
	}

	public void setProvincialnumber(int provincialnumber) {
		this.provincialnumber = provincialnumber;
	}

	public int getMunicipalnumber() {
		return municipalnumber;
	}

	public void setMunicipalnumber(int municipalnumber) {
		this.municipalnumber = municipalnumber;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
