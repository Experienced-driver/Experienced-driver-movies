package com.hwadee.tb.student.persistence;

import java.util.List;

import com.hwadee.tb.student.domain.Major;
import com.hwadee.tb.student.domain.Situation;
import com.hwadee.tb.student.domain.Student;

public interface StudentMapper {
	
	void insertStudent(Student student);
	void updateStudent(Student student);
	Student getStudentByAccountId(int accountId);
	
	void insertSituation(Situation situation);
	void updateSituation(Situation situation);
	Situation getSituationByAccountId(int accountId);
	
	void insertMajor(Major major);
	void updateMajor(Major major);
	List<Major> getMajorlist(int parentid);
	Major getMajorByid(int id);
	void deleteMajor(int id);
	
}
