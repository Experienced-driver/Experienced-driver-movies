package com.hwadee.tb.train.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.teacher.controller.TeacherController;
import com.hwadee.tb.teacher.domain.Course;
import com.hwadee.tb.teacher.service.TeacherService;
import com.hwadee.tb.train.domain.Train;
import com.hwadee.tb.train.service.TrainService;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
@RequestMapping("train")
public class TrainController extends AbstractController {

	private static final String PSX_VIEW = "train/pxs";
	private static final String EDIT_VIEW = "train/editPxs";
	private static final String XNSX_VIEW = "train/xnsx";
	private static final String GGSX_VIEW = "train/ggsx";
	private static final String XWSX_VIEW = "train/xwsx";
	private static final int XIAONEI_VALUE = 1;
	private static final int GONGGONG_VALUE = 2;
	private static final int XIAOWAI_VALUE = 3;
	
	@Resource(name="trainService")
	private TrainService trainService;
	
	@Resource(name="teacherService")
	private TeacherService teacherService;
	
	@RequestMapping(method=RequestMethod.GET, value="pxs")
	ModelAndView pxs(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session,int zhuanye1,int zhuanye2,int zhuanye3) {
		ModelAndView mav = init(T, PSX_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		Train obj = new Train();
		obj.setAccount_id(account.getId());
		
		
		obj.setLexing(XIAONEI_VALUE);
		obj.setZhuanye(zhuanye1);
		Train trainByAccountId = trainService.getTrainByAccountId(obj);
		mav.addObject("train1", trainByAccountId);
		
		obj.setLexing(GONGGONG_VALUE);
		obj.setZhuanye(zhuanye2);
		mav.addObject("train2", trainService.getTrainByAccountId(obj));
		
		obj.setLexing(XIAOWAI_VALUE);
		obj.setZhuanye(zhuanye3);
		mav.addObject("train3", trainService.getTrainByAccountId(obj));
		mav.addObject("courseList", teacherService.getCourseList(TeacherController.TYPE_TRAING));
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="editPxs")
	ModelAndView editPxs(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session, @ModelAttribute Train obj) {
		String url = EDIT_VIEW;
		if (obj.getLexing()==XIAONEI_VALUE) {
			url = XNSX_VIEW;
			
		}else if (obj.getLexing()==GONGGONG_VALUE) {
			url = GGSX_VIEW;
			
		}else if(obj.getLexing()==XIAOWAI_VALUE){
			url = XWSX_VIEW;
		}
		ModelAndView mav = init(T, url);
		boolean isNew = false;
		Account account = (Account) session.getAttribute("account");
		obj.setAccount_id(account.getId());
		Train train = trainService.getTrainByAccountId(obj);
		
		if (null == train) {
			train = new Train();
			train.setAccount_id(account.getId());
			train.setLexing(obj.getLexing());
			train.setZhuanye(obj.getZhuanye());
			isNew = true;
		}
		mav.addObject("typeList", getPxsType());
		mav.addObject("courseList", teacherService.getCourseList(TeacherController.TYPE_TRAING));
		mav.addObject("isNew", isNew);
		mav.addObject("train", train);
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="save/{action}")
	ModelAndView save_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute  Train obj) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				trainService.insertTrain(obj);
				resultInfo = "写入记录成功！";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				trainService.updateTrain(obj);
				resultInfo = "更新记录成功！";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "写入或更新失败！";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	
	private  List<Course> getPxsType(){
		 List<Course> list = new ArrayList<Course>();
		 list.add(createCourse(1,"校内实训基地"));
		 list.add(createCourse(2,"公共实训基地"));
		 list.add(createCourse(3,"校外实训基地"));
		return list;
	}

	private Course createCourse(int id, String name) {
		Course course1 = new Course();
		course1.setId(id);
		course1.setName(name);
		return course1;
	}

	@RequestMapping(method=RequestMethod.POST, value="pxs/{action}")
	ModelAndView pxs_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Train obj) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				trainService.insertTrain(obj);
				resultInfo = "写入记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				trainService.updateTrain(obj);
				resultInfo = "更新记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
}
