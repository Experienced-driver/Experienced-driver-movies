package com.hwadee.tb.train.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.train.domain.Train;
import com.hwadee.tb.train.persistence.TrainMapper;

@Service
public class TrainService {

	@Autowired
	private TrainMapper trainMapper;
	
	public Train getTrainByAccountId(Train train) {
		return trainMapper.getTrainByAccountId(train);
	}
	
	public void insertTrain(Train train) {
		trainMapper.insertTrain(train);
	}
	
	public void updateTrain(Train train) {
		trainMapper.updateTrain(train);
	}
	
	public List<Train> getTrainListByAccountId(int AccountId){
		return trainMapper.getTrainListByAccountId(AccountId);
	}
	
	
	
}
