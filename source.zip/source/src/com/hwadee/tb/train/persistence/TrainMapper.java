package com.hwadee.tb.train.persistence;

import java.util.List;

import com.hwadee.tb.train.domain.Train;


public interface TrainMapper {
	
	Train getTrainByAccountId(Train train);
	void insertTrain(Train train);
	void updateTrain(Train train);
	List<Train> getTrainListByAccountId(int AccountId);
}
