package com.hwadee.tb.train.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Train implements Serializable {
	private int id;
	private int lexing;// 培训室类型
	private int zhuanye;// 专业
	private String shixunjidi;// 实训基地名称
	private String shixunshi;// 实训室名称
	private int taoshu_count;// 实训室内设施设备台套数
	private int zongzhi_count;// 设施设备总值
	private int gongwei_count;// 工位数
	private String kecheng;// 对外开放课程名称
	private int kecheng_count;// 课程数
	private int keshi_count;// 课时数
	private int account_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getLexing() {
		return lexing;
	}
	public void setLexing(int lexing) {
		this.lexing = lexing;
	}
	public int getZhuanye() {
		return zhuanye;
	}
	public void setZhuanye(int zhuanye) {
		this.zhuanye = zhuanye;
	}
	public String getShixunjidi() {
		return shixunjidi;
	}
	public void setShixunjidi(String shixunjidi) {
		this.shixunjidi = shixunjidi;
	}
	public String getShixunshi() {
		return shixunshi;
	}
	public void setShixunshi(String shixunshi) {
		this.shixunshi = shixunshi;
	}
	public int getTaoshu_count() {
		return taoshu_count;
	}
	public void setTaoshu_count(int taoshu_count) {
		this.taoshu_count = taoshu_count;
	}
	public int getZongzhi_count() {
		return zongzhi_count;
	}
	public void setZongzhi_count(int zongzhi_count) {
		this.zongzhi_count = zongzhi_count;
	}
	public int getGongwei_count() {
		return gongwei_count;
	}
	public void setGongwei_count(int gongwei_count) {
		this.gongwei_count = gongwei_count;
	}
	public String getKecheng() {
		return kecheng;
	}
	public void setKecheng(String kecheng) {
		this.kecheng = kecheng;
	}
	public int getKecheng_count() {
		return kecheng_count;
	}
	public void setKecheng_count(int kecheng_count) {
		this.kecheng_count = kecheng_count;
	}
	public int getKeshi_count() {
		return keshi_count;
	}
	public void setKeshi_count(int keshi_count) {
		this.keshi_count = keshi_count;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
