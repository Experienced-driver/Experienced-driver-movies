package com.hwadee.tb.sign.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.sign.persistence.SignMapper;

@Service
public class SignService {

	@Autowired
	private SignMapper signMapper;
	
	public int testMysql() {
		return signMapper.testMysql();
	}
	
	public Account getAccountByCodeAndPwd(Account account) {
		return signMapper.getAccountByCodeAndPwd(account);
	}
	
	public Account getAccountByCodeOrUsername(Account account) {
		return signMapper.getAccountByCodeOrUsername(account);
	}
	
	public void insertAccount(Account account) {
		signMapper.insertAccount(account);
	}
	
	public void updateAccount(Account account) {
		signMapper.updateAccount(account);
	}
}
