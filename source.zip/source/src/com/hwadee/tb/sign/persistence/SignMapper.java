package com.hwadee.tb.sign.persistence;

import com.hwadee.tb.sign.domain.Account;

public interface SignMapper {
	
	int testMysql();
	
	Account getAccountByCodeAndPwd(Account account);
	Account getAccountByCodeOrUsername(Account account);
	void insertAccount(Account account);
	void updateAccount(Account account);
}
