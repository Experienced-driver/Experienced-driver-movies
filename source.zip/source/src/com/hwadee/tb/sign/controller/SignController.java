package com.hwadee.tb.sign.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.sign.service.SignService;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
public class SignController extends AbstractController {
	// 日志
	private static Log log = LogFactory.getLog(SignController.class);
	
	private static final String INDEX_VIEW = "index";
	private static final String NOTICE_VIEW = "notice";
	private static final String SCHOOL_PAGE_VIEW = "school_page";
	private static final String TOP_VIEW = "top";
	private static final String BOTTOM_VIEW = "bottom";
	private static final String NAV_VIEW = "nav";
	private static final String REGISTER_VIEW = "register";
	private static final String ADMIN_VIEW = "admin";
	
	@Resource(name="signService")
	private SignService signService;
	
	@RequestMapping(method=RequestMethod.GET, value="/")
	ModelAndView index(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T) {

		ModelAndView mav = init(T, INDEX_VIEW);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="sign_in")
	ModelAndView sign_in(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@ModelAttribute Account account, HttpSession session) {
		
		account = signService.getAccountByCodeAndPwd(account);
		log.debug(account);
		
		ModelAndView mav = init(T, null);
		if (null == account || 0 == account.getId()) {
			account = new Account();
			account.setUsername("学校代码或登录密码错误");
		}
		else {
			session.setAttribute("account", account);
			session.setMaxInactiveInterval(60*60);
		}
		
		mav.addObject("account", account);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="notice")
	ModelAndView notice(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {

		ModelAndView mav = init(T, NOTICE_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		mav.addObject("account", account);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="school_page")
	ModelAndView school_page(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T) {

		ModelAndView mav = init(T, SCHOOL_PAGE_VIEW);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="top")
	ModelAndView top(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {

		ModelAndView mav = init(T, TOP_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		mav.addObject("account", account);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="nav")
	ModelAndView nav(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T) {

		ModelAndView mav = init(T, NAV_VIEW);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="bottom")
	ModelAndView bottom(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T) {

		ModelAndView mav = init(T, BOTTOM_VIEW);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="register")
	ModelAndView register(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T) {

		ModelAndView mav = init(T, REGISTER_VIEW);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="register/done")
	ModelAndView register_done(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@ModelAttribute Account account) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		Account accountExist = signService.getAccountByCodeOrUsername(account);
		
		if (null == accountExist) {
			try {
				signService.insertAccount(account);
				resultInfo = "帐号注册成功，返回首页登录";
			}
			catch (Exception e) {
				e.printStackTrace();
				isFailure = true;
				resultInfo = "帐号注册失败，数据库异常";
			}
		}
		else {
			isFailure = true;
			resultInfo = "帐号注册失败，学校代码或账号已经存在\n"
					+ "代码：" + account.getCode() + "\n"
					+ "帐号：" + account.getUsername();
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="admin")
	ModelAndView admin(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {

		ModelAndView mav = init(T, ADMIN_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		mav.addObject("account", account);
		
		return mav;
	}

}
