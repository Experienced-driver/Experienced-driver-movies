package com.hwadee.tb.teacher.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.teacher.domain.BasicSituation;
import com.hwadee.tb.teacher.domain.Course;
import com.hwadee.tb.teacher.domain.Ggk;
import com.hwadee.tb.teacher.domain.Zydl;
import com.hwadee.tb.teacher.persistence.TeacherMapper;

@Service
public class TeacherService {

	@Autowired
	private TeacherMapper teacherMapper;
	
	public BasicSituation getBasicSituationByAccountId(int accountId) {
		return teacherMapper.getBasicSituationByAccountId(accountId);
	}
	
	public void insertBasicSituation(BasicSituation basicSituation) {
		teacherMapper.insertBasicSituation(basicSituation);
	}
	
	public void updateBasicSituation(BasicSituation basicSituation) {
		teacherMapper.updateBasicSituation(basicSituation);
	}
	
	public Ggk getGgkByCourseIdAndAccountId(Ggk ggk){
		return teacherMapper.getGgkByCourseIdAndAccountId(ggk);
	}
	
	public Ggk getGgkByAccountId(int accountId) {
		return teacherMapper.getGgkByAccountId(accountId);
	}
	
	public void insertGgk(Ggk ggk) {
		teacherMapper.insertGgk(ggk);
	}
	
	public void updateGgk(Ggk ggk) {
		teacherMapper.updateGgk(ggk);
	}
	
	public Zydl getZydlByMajorIdAndAccountId(Zydl zydl) {
		return teacherMapper.getZydlByMajorIdAndAccountId(zydl);
	}
	
	public Zydl getZydlByAccountId(int accountId) {
		return teacherMapper.getZydlByAccountId(accountId);
	}
	
	public void insertZydl(Zydl zydl) {
		teacherMapper.insertZydl(zydl);
	}
	
	public void updateZydl(Zydl zydl) {
		teacherMapper.updateZydl(zydl);
	}
	
	public List<Course> getCourseList(int type) {
		return teacherMapper.getCourseList(type);
	}
	
	public Course getCourseById(int id) {
		return teacherMapper.getCourseById(id);
	}
	
	public void insertCourse(Course course){
		teacherMapper.insertCourse(course);
	}
	
	public void deleteCourse(Course course){
		teacherMapper.deleteCourse(course);
	}
	
	public void updateCourse(Course course){
		teacherMapper.updateCourse(course);
	}
	
}
