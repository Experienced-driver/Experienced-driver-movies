package com.hwadee.tb.teacher.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Zydl implements Serializable {

	private int id;
	private int major_id;// 专业大类id
	private String professional;// 主打专业
	private int jiaoshishu_count;// 教师数
	private int daitouren_count;// 校级以上专业带头人数
	private int zhicheng_count;// 中高职称数
	private int shuangshixing_count;// 双师型教师数
	private int gugan_count;// 骨干教师数
	private int yanjiusheng_count;// 具有研究生学历或学位的专任教师数
	private int benke_count;// 本科及以上学历专任教师数
	private int shenjiyishang_count;// 参加省级以上培训专任教师数
	private int shenjiyixia_count;// 参加省级以下培训专任教师数
	private int guowai_count;// 参加国外培训专任教师数
	private int guojia_count;// 参加国家级培训专任教师数
	private int account_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMajor_id() {
		return major_id;
	}
	public void setMajor_id(int major_id) {
		this.major_id = major_id;
	}
	public int getJiaoshishu_count() {
		return jiaoshishu_count;
	}
	public void setJiaoshishu_count(int jiaoshishu_count) {
		this.jiaoshishu_count = jiaoshishu_count;
	}
	public int getDaitouren_count() {
		return daitouren_count;
	}
	public void setDaitouren_count(int daitouren_count) {
		this.daitouren_count = daitouren_count;
	}
	public int getZhicheng_count() {
		return zhicheng_count;
	}
	public void setZhicheng_count(int zhicheng_count) {
		this.zhicheng_count = zhicheng_count;
	}
	public int getShuangshixing_count() {
		return shuangshixing_count;
	}
	public void setShuangshixing_count(int shuangshixing_count) {
		this.shuangshixing_count = shuangshixing_count;
	}
	public int getGugan_count() {
		return gugan_count;
	}
	public void setGugan_count(int gugan_count) {
		this.gugan_count = gugan_count;
	}
	public int getYanjiusheng_count() {
		return yanjiusheng_count;
	}
	public void setYanjiusheng_count(int yanjiusheng_count) {
		this.yanjiusheng_count = yanjiusheng_count;
	}
	public int getBenke_count() {
		return benke_count;
	}
	public void setBenke_count(int benke_count) {
		this.benke_count = benke_count;
	}
	public int getShenjiyishang_count() {
		return shenjiyishang_count;
	}
	public void setShenjiyishang_count(int shenjiyishang_count) {
		this.shenjiyishang_count = shenjiyishang_count;
	}
	public int getShenjiyixia_count() {
		return shenjiyixia_count;
	}
	public void setShenjiyixia_count(int shenjiyixia_count) {
		this.shenjiyixia_count = shenjiyixia_count;
	}
	public int getGuowai_count() {
		return guowai_count;
	}
	public void setGuowai_count(int guowai_count) {
		this.guowai_count = guowai_count;
	}
	public int getGuojia_count() {
		return guojia_count;
	}
	public void setGuojia_count(int guojia_count) {
		this.guojia_count = guojia_count;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getProfessional() {
		return professional;
	}
	public void setProfessional(String professional) {
		this.professional = professional;
	}

}
