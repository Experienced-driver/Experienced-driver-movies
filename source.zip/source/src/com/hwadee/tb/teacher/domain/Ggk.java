package com.hwadee.tb.teacher.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Ggk implements Serializable {

	private int id;
	private int course_id;
	private int leader_count; // 校级以上专业带头人数
	private int advance_count;// 高级职称教师数
	private int major_count; // 骨干教师数
	private int double_count; // 双师型教师数
	private int benke_count; // 本科及以上学历专业任教师数
	private int yanjiusheng_count; // 具有研究生学历或学位的专任教师数
	private int shengji_count; // 参加省级以下培训专任教师数
	private int shengji2_count; // 参加省级以上培训专任教师数
	private int guojia_count; // 参加国家级培训专任教师数
	private int guoji_count; // 参加国外培训专任教师数
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getLeader_count() {
		return leader_count;
	}

	public void setLeader_count(int leader_count) {
		this.leader_count = leader_count;
	}

	public int getAdvance_count() {
		return advance_count;
	}

	public void setAdvance_count(int advance_count) {
		this.advance_count = advance_count;
	}

	public int getMajor_count() {
		return major_count;
	}

	public void setMajor_count(int major_count) {
		this.major_count = major_count;
	}

	public int getDouble_count() {
		return double_count;
	}

	public void setDouble_count(int double_count) {
		this.double_count = double_count;
	}

	public int getBenke_count() {
		return benke_count;
	}

	public void setBenke_count(int benke_count) {
		this.benke_count = benke_count;
	}

	public int getYanjiusheng_count() {
		return yanjiusheng_count;
	}

	public void setYanjiusheng_count(int yanjiusheng_count) {
		this.yanjiusheng_count = yanjiusheng_count;
	}

	public int getShengji_count() {
		return shengji_count;
	}

	public void setShengji_count(int shengji_count) {
		this.shengji_count = shengji_count;
	}

	public int getShengji2_count() {
		return shengji2_count;
	}

	public void setShengji2_count(int shengji2_count) {
		this.shengji2_count = shengji2_count;
	}

	public int getGuojia_count() {
		return guojia_count;
	}

	public void setGuojia_count(int guojia_count) {
		this.guojia_count = guojia_count;
	}

	public int getGuoji_count() {
		return guoji_count;
	}

	public void setGuoji_count(int guoji_count) {
		this.guoji_count = guoji_count;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
