package com.hwadee.tb.teacher.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BasicSituation implements Serializable {
	private int id;
	private int teacher_total; // 教职工总数
	private int teacher_in_total; // 在编在职教职工数
	private int teacher_regs; // 教职工编制数
	private int teacher_ins; // 专任教师数
	private int teacher_outs; // 外聘教师数
	private int account_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTeacher_total() {
		return teacher_total;
	}
	public void setTeacher_total(int teacher_total) {
		this.teacher_total = teacher_total;
	}
	public int getTeacher_in_total() {
		return teacher_in_total;
	}
	public void setTeacher_in_total(int teacher_in_total) {
		this.teacher_in_total = teacher_in_total;
	}
	public int getTeacher_regs() {
		return teacher_regs;
	}
	public void setTeacher_regs(int teacher_regs) {
		this.teacher_regs = teacher_regs;
	}
	public int getTeacher_ins() {
		return teacher_ins;
	}
	public void setTeacher_ins(int teacher_ins) {
		this.teacher_ins = teacher_ins;
	}
	public int getTeacher_outs() {
		return teacher_outs;
	}
	public void setTeacher_outs(int teacher_outs) {
		this.teacher_outs = teacher_outs;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
}
