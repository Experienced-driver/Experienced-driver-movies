package com.hwadee.tb.teacher.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.teacher.domain.BasicSituation;
import com.hwadee.tb.teacher.domain.Course;
import com.hwadee.tb.teacher.domain.Ggk;
import com.hwadee.tb.teacher.domain.Zydl;
import com.hwadee.tb.teacher.service.TeacherService;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
@RequestMapping("teacher")
public class TeacherController extends AbstractController {
	private static Log log = LogFactory.getLog(TeacherController.class);
	
	public static final int TYPE_COURSE = 1;//科目
	public static final int TYPE_TRAING = 2;//专业
	private static final String BASIC_SITUATION_VIEW = "teacher/basicSituation";
	private static final String GGK_VIEW = "teacher/ggk";
	private static final String ZYDL_VIEW = "teacher/zydl";
	private static final String SUBJECT_LIST_VIEW = "teacher/subject/subjectList";
	private static final String SUBJECT_ADD_VIEW = "teacher/subject/addSubject";
	
	@Resource(name="teacherService")
	private TeacherService teacherService;
	
	@RequestMapping(method=RequestMethod.GET, value="basicSituation")
	ModelAndView basicSituation(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, BASIC_SITUATION_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		BasicSituation basicSituation = teacherService.getBasicSituationByAccountId(account.getId());
		
		if (null == basicSituation) {
			basicSituation = new BasicSituation();
			basicSituation.setAccount_id(account.getId());
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(basicSituation);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("basicSituation", basicSituation);
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="basicSituation/{action}")
	ModelAndView basicSituation_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute BasicSituation basicSituation) {
		ModelAndView mav = init(T, null);
		String resultInfo = null;
		boolean isFailure = false;
		
		log.debug(basicSituation);
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.insertBasicSituation(basicSituation);
				resultInfo = "写入教职工总数记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.updateBasicSituation(basicSituation);;
				resultInfo = "写入教职工总数记录成功";
			}
		}
		catch(Exception e) {
			isFailure = true;
			e.printStackTrace();
			resultInfo = "教职工总数写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="ggk")
	ModelAndView ggk(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session,int course_id) {
		ModelAndView mav = init(T, GGK_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Ggk obj = new Ggk();
		obj.setAccount_id(account.getId());
		obj.setCourse_id(course_id);
		Ggk ggk = teacherService.getGgkByCourseIdAndAccountId(obj);
		if (null == ggk) {
			ggk = new Ggk();
			ggk.setAccount_id(account.getId());
			ggk.setCourse_id(course_id);
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		if (course_id==-1) {
			readonly = true;
		}
		
		log.debug(ggk);
		mav.addObject("courseList", teacherService.getCourseList(TYPE_COURSE));
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("ggk", ggk);
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="ggk/{action}")
	ModelAndView ggk_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Ggk ggk) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(ggk);
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.insertGgk(ggk);
				resultInfo = "写入公共课记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.updateGgk(ggk);
				resultInfo = "更新公共课记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "公共课写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="zydl")
	ModelAndView zydl(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session,int major_id) {
		ModelAndView mav = init(T, ZYDL_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Zydl obj = new Zydl();
		obj.setAccount_id(account.getId());
		obj.setMajor_id(major_id);
		Zydl zydl = teacherService.getZydlByMajorIdAndAccountId(obj);
		
		if (null == zydl) {
			zydl = new Zydl();
			zydl.setAccount_id(account.getId());
			zydl.setMajor_id(major_id);
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		if (major_id==-1) {
			readonly = true;
		}
		log.debug(zydl);
		mav.addObject("courseList", teacherService.getCourseList(TYPE_TRAING));
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("zydl", zydl);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="zydl/{action}")
	ModelAndView zydl_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Zydl zydl) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(zydl);
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.insertZydl(zydl);
				resultInfo = "写入专业大类记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.updateZydl(zydl);
				resultInfo = "更新专业大类记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "专业大类写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="subjectList")
	ModelAndView subjectList(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, SUBJECT_LIST_VIEW);
		mav.addObject("courseList", teacherService.getCourseList(TYPE_COURSE));
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="addSubject")
	ModelAndView addSubject(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, SUBJECT_ADD_VIEW);
		mav.addObject("isNew", true);
		mav.addObject("course", new Course());
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="updateSubject")
	ModelAndView updateSubject(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session,int id) {
		ModelAndView mav = init(T, SUBJECT_ADD_VIEW);
		mav.addObject("isNew", false);
		mav.addObject("course", teacherService.getCourseById(id));
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="delSubject")
	ModelAndView delSubject(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session,int id) {
		teacherService.deleteCourse(teacherService.getCourseById(id));
		ModelAndView mav = init(T, SUBJECT_LIST_VIEW);
		mav.addObject("courseList", teacherService.getCourseList(TYPE_COURSE));
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="subject/{action}")
	ModelAndView subject_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Course course) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(course);
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				course.setType(TYPE_COURSE);
				teacherService.insertCourse(course);
				resultInfo = "写入科目记录成功！";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				teacherService.updateCourse(course);
				resultInfo = "更新科目记录成功！";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "科目名称已存在，请重新输入！";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
}
