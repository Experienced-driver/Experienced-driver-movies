package com.hwadee.tb.teacher.persistence;

import java.util.List;

import com.hwadee.tb.teacher.domain.BasicSituation;
import com.hwadee.tb.teacher.domain.Course;
import com.hwadee.tb.teacher.domain.Ggk;
import com.hwadee.tb.teacher.domain.Zydl;

public interface TeacherMapper {
	
	BasicSituation getBasicSituationByAccountId(int accountId);
	void insertBasicSituation(BasicSituation basicSituation);
	void updateBasicSituation(BasicSituation basicSituation);
	
	Ggk getGgkByCourseIdAndAccountId(Ggk ggk);
	Ggk getGgkByAccountId(int accountId);
	void insertGgk(Ggk ggk);
	void updateGgk(Ggk ggk);
	
	Zydl getZydlByMajorIdAndAccountId(Zydl zydl);
	Zydl getZydlByAccountId(int accountId);
	void insertZydl(Zydl zydl);
	void updateZydl(Zydl zydl);
	
	void insertCourse(Course course);
	void deleteCourse(Course course);
	void updateCourse(Course course);
	Course getCourseById(int id);
	List<Course> getCourseList(int type);
}
