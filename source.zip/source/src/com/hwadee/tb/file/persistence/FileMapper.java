/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  上午9:57:04
 *@desc:
 */
package com.hwadee.tb.file.persistence;

import java.util.List;

import com.hwadee.tb.file.domain.FileModel;
import com.hwadee.tb.file.domain.FileTemplateModel;

/**
 * @author xiangping
 *
 */
public interface FileMapper {
	void insertFileTemplate(FileTemplateModel fileTemplateModel);
	
	void delFileTemplate(String id);

	FileTemplateModel getFileTemplateByid(FileTemplateModel fileTemplateModel);

	List<FileTemplateModel> getFileTemplateModelList();
	
	void insertFile(FileModel fileModel);
	
	void delFile(String id);
	
	FileModel getFileModel(FileModel fileModel);
	
	List<FileModel> getFileModelList(FileModel fileModel);
	
	List<FileModel> getFileModelCount(FileModel fileModel);
}
