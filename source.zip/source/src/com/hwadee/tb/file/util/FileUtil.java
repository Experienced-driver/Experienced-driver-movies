/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  下午1:12:06
 *@desc:
 */
package com.hwadee.tb.file.util;

import java.io.File;
import java.io.FileOutputStream;

import org.springframework.web.multipart.MultipartFile;

import com.hwadee.tb.util.COMMON;

/**
 * @author xiangping
 *
 */
public class FileUtil {
	private static String basePath = COMMON.property("dir.upload");

	/**
	 * 上传文件
	 * 
	 * @param request
	 * @param path
	 * @param filename
	 * @throws Exception
	 */
	public static String doUpload(MultipartFile myfiles, String tempDir,
			String asis) throws Exception {
		String realFilePath = "";
		try {
			File myPath = new File(basePath + tempDir);
			if (!myPath.exists()) {
				myPath.mkdirs();
			}

			realFilePath = tempDir + "/"
					+ getFileName(myfiles.getOriginalFilename()) + "(" + asis
					+ ")" + getFileExtName(myfiles.getOriginalFilename());

			FileOutputStream outputStream = new FileOutputStream(basePath
					+ realFilePath);
			outputStream.write(myfiles.getBytes());
			outputStream.close();

			// DiskFileItemFactory factory = new DiskFileItemFactory();
			// factory.setSizeThreshold(4096);
			//
			// ServletFileUpload uploader = new ServletFileUpload(factory);
			// List<FileItem> list = uploader.parseRequest(request);
			// Iterator<FileItem> iterator = list.iterator();
			// while (iterator.hasNext()) {
			// FileItem item = iterator.next();
			// if (!item.isFormField()) {
			// String filename = item.getName();
			// fullFilePath = basePath + tempDir + "/"
			// + getFileName(filename) + "(" + asis + ")" + "."
			// + getFileExtName(filename);
			// item.write(new File(fullFilePath));
			// }
			// }

		} catch (Exception e) {
			throw new Exception("上传文件出错:" + e.getMessage());
		}
		return realFilePath;
	}

	/**
	 * 获取文件名
	 * 
	 * @param filename
	 * @return
	 */
	public static String getFileName(String filename) {
		String name = filename.substring(0, filename.lastIndexOf("."));
		return name;
	}

	/**
	 * 获取文件扩展名
	 * 
	 * @param filename
	 * @return
	 */
	public static String getFileExtName(String filename) {
		String name = filename.substring(filename.lastIndexOf("."),
				filename.length());
		return name;
	}
	
	/**
	 * 删除文件
	 * @param filename
	 */
	public static void delFile(String filename){
		File file=new File(filename);
		if (file.isFile()&&file.exists()) {
			file.delete();
		}
	}
}
