/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  上午10:37:39
 *@desc:
 */
package com.hwadee.tb.file.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.file.domain.FileModel;
import com.hwadee.tb.file.domain.FileTemplateModel;
import com.hwadee.tb.file.persistence.FileMapper;

/**
 * @author xiangping
 *
 */
@Service
public class FileService {
	@Autowired
	private FileMapper fileMapper;

	public void insertFileTemplate(FileTemplateModel fileTemplateModel) {
		fileMapper.insertFileTemplate(fileTemplateModel);
	}

	public List<FileTemplateModel> geTemplateModelList() {
		return fileMapper.getFileTemplateModelList();
		//return null;
	}
	
	public FileTemplateModel getFileTemplateByid(FileTemplateModel fileTemplateModel){
		return fileMapper.getFileTemplateByid(fileTemplateModel);
	}
	
	public void insertFile(FileModel fileModel){
		fileMapper.insertFile(fileModel);
	}
	
	public FileModel getFileModel(FileModel fileModel){
		return fileMapper.getFileModel(fileModel);
	}
	
	public List<FileModel> getFileModelList(FileModel fileModel){
		return fileMapper.getFileModelList(fileModel);	
		//return null;
	}
	
	public List<FileModel> getFileModelCount(FileModel fileModel){
		return fileMapper.getFileModelCount(fileModel);
	}
	
	public void delFileTemplate(String id){
		 fileMapper.delFileTemplate(id);
	}
	
	public void delFile(String id){
		fileMapper.delFile(id);
	}
}
