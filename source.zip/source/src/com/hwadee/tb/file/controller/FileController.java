/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  上午9:49:10
 *@desc:
 */
package com.hwadee.tb.file.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.file.domain.DataGrid;
import com.hwadee.tb.file.domain.FileModel;
import com.hwadee.tb.file.domain.FileTemplateModel;
import com.hwadee.tb.file.domain.PageHelp;
import com.hwadee.tb.file.service.FileService;
import com.hwadee.tb.file.util.FileUtil;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.util.COMMON;

/**
 * @author xiangping
 *
 */
@Controller
@RequestMapping("file")
public class FileController extends AbstractController {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger(FileController.class);

	private static final String FILETEMPLATE_MANAGER = "file/filetemplate/filetemplate_manager";
	private static final String FILE_MANAGER = "file/file_manager";

	@Autowired
	private FileService fileService;

	@RequestMapping("/filetemplatemanager")
	public String filetemplatemanager(HttpServletRequest request) {
		return FILETEMPLATE_MANAGER;
	}
	
	@RequestMapping("/filemanager")
	public String filemanager(HttpServletRequest request){
		return FILE_MANAGER;
	}

	/**
	 * 获取模板datagrid
	 * 
	 * @param session
	 * @param pageHelp
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "templatedatagrid")
	@ResponseBody
	public DataGrid templatedatagrid(HttpSession session, PageHelp pageHelp) {
		Account account = (Account) session.getAttribute("account");
		logger.info(account.getUsername());
		logger.info(account.getId());

		DataGrid dataGrid = new DataGrid();
		List<FileTemplateModel> list = new ArrayList<>();
		list = fileService.geTemplateModelList();

		dataGrid.setRows(list);
		dataGrid.setTotal(Long.parseLong(String.valueOf(list.size())));
		return dataGrid;
	}

	/**
	 * 上传文件模板
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "uploadTemplateFile")
	public String uploadTemplateFile(@RequestParam MultipartFile[] myfiles,
			HttpSession session, FileTemplateModel fileTemplateModel)
			throws Exception {
		String id = COMMON.UUID();
		String filepath = FileUtil.doUpload(myfiles[0], "/template/", id);
		Account account = (Account) session.getAttribute("account");

		fileTemplateModel.setId(id);
		fileTemplateModel.setFilepath(filepath);
		fileTemplateModel.setUserid(String.valueOf(account.getId()));

		fileService.insertFileTemplate(fileTemplateModel);
		return FILETEMPLATE_MANAGER;
	}

	/**
	 * 删除文档模板
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "delTemplateFile")
	@ResponseBody
	public DataGrid delTemplateFile(String id)
			throws Exception {
		FileTemplateModel fileTemplateModel=new FileTemplateModel();
		fileTemplateModel.setId(id);
		fileTemplateModel=fileService.getFileTemplateByid(fileTemplateModel);
		 
		String filepath=COMMON.property("dir.upload")+fileTemplateModel.getFilepath();
		FileUtil.delFile(filepath);
		fileService.delFileTemplate(id);
		
		DataGrid dataGrid = new DataGrid();
		List<FileTemplateModel> list = new ArrayList<>();
		list = fileService.geTemplateModelList();

		dataGrid.setRows(list);
		dataGrid.setTotal(Long.parseLong(String.valueOf(list.size())));
		return dataGrid;
	}
	
	/**
	 * 下载文件模板
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "downFile")
	public void downFile(String id, HttpServletResponse response)
			throws IOException {
		FileTemplateModel fileTemplateModel = new FileTemplateModel();
		fileTemplateModel.setId(id);
		fileTemplateModel = fileService.getFileTemplateByid(fileTemplateModel);
		String filename = COMMON.property("dir.upload")
				+ fileTemplateModel.getFilepath();

		/*
		 * // path是指欲下载的文件的路径。 File file = new File(filename1); // 取得文件名。 String
		 * filename = file.getName(); // 取得文件的后缀名。 String ext =
		 * filename.substring(filename.lastIndexOf(".") + 1) .toUpperCase();
		 * 
		 * // 以流的形式下载文件。 InputStream fis = new BufferedInputStream( new
		 * FileInputStream(filename1)); byte[] buffer = new
		 * byte[fis.available()]; fis.read(buffer); fis.close(); // 清空response
		 * response.reset(); // 设置response的Header
		 * response.addHeader("Content-Disposition", "attachment;filename=" +
		 * new String(filename.getBytes()));
		 * response.addHeader("Content-Length", "" + file.length());
		 * OutputStream toClient = new BufferedOutputStream(
		 * response.getOutputStream());
		 * response.setContentType("application/octet-stream");
		 * toClient.write(buffer); toClient.flush(); toClient.close();
		 * 
		 * return response;
		 */

		File file = new File(filename);
		response.reset();

		// 取下载的文件名称
		String downfile = filename.substring(filename.lastIndexOf("/") + 1,
				filename.length());
		logger.info(downfile);
		logger.info(file.getName());

		response.addHeader("Content-Disposition", "attachment;filename="
				+ new String(file.getName().replaceAll("("+fileTemplateModel.getId()+")", "").getBytes("gbk"), "iso-8859-1")); // 转码之后下载的文件不会出现中文乱码
		response.addHeader("Content-Length", "" + file.length());

		try {
			InputStream fis = new BufferedInputStream(new FileInputStream(
					filename));
			byte[] buffer = new byte[fis.available()];
			fis.read(buffer);
			fis.close();

			OutputStream toClient = new BufferedOutputStream(
					response.getOutputStream());
			toClient.write(buffer);
			toClient.flush();
			toClient.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取个人文件datagrid
	 * 
	 * @param session
	 * @param pageHelp
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "filedatagrid")
	@ResponseBody
	public DataGrid filedatagrid(HttpSession session, PageHelp pageHelp,FileModel fileModel) {
		// Account account = (Account) session.getAttribute("account");
		// 考虑是否只看自己的 还是看全部的

		fileModel.setStartrow((pageHelp.getPage()-1)*pageHelp.getRows());
		fileModel.setPagesize(pageHelp.getRows());
		if (fileModel.getFilename()!=null && fileModel.getFilename()!="") {
			fileModel.setFilename(MessageFormat.format("%{0}%", fileModel.getFilename()));
		}
		
		
		DataGrid dataGrid = new DataGrid();
		List<FileModel> list = new ArrayList<>();
		List<FileModel> listcount = new ArrayList<>();
		list = fileService.getFileModelList(fileModel);
		listcount=fileService.getFileModelCount(fileModel);

		dataGrid.setRows(list);
		dataGrid.setTotal(Long.parseLong(String.valueOf(listcount.size())));
		return dataGrid;
	}

	/**
	 * 上传个人附件
	 * 
	 * @param myfiles
	 * @param session
	 * @param fileModel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST, value = "uploadFile")
	public String uploadFile(@RequestParam MultipartFile[] myfiles,
			HttpSession session, FileModel fileModel) throws Exception {
		String id = COMMON.UUID();
		String filepath = FileUtil.doUpload(myfiles[0], "", id);
		Account account = (Account) session.getAttribute("account");

		fileModel.setId(id);
		fileModel.setFilepath(filepath);
		fileModel.setUserid(String.valueOf(account.getId()));

		fileService.insertFile(fileModel);
		return FILE_MANAGER;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "delFile")
	@ResponseBody
	public DataGrid delFile(String id,PageHelp pageHelp) throws Exception {
		FileModel fileModel=new FileModel();
		fileModel.setId(id);
		fileModel=fileService.getFileModel(fileModel);
		
		String filePath=COMMON.property("dir.upload")+fileModel.getFilepath();
		FileUtil.delFile(filePath);
		fileService.delFile(id);
		
		
		fileModel.setStartrow((pageHelp.getPage()-1)*pageHelp.getRows());
		fileModel.setPagesize(pageHelp.getRows());
		if (fileModel.getFilename()!=null && fileModel.getFilename()!="") {
			fileModel.setFilename(MessageFormat.format("%{0}%", fileModel.getFilename()));
		}
		
		
		DataGrid dataGrid = new DataGrid();
		List<FileModel> list = new ArrayList<>();
		List<FileModel> listcount = new ArrayList<>();
		list = fileService.getFileModelList(fileModel);
		listcount=fileService.getFileModelCount(fileModel);

		dataGrid.setRows(list);
		dataGrid.setTotal(Long.parseLong(String.valueOf(listcount.size())));
		return dataGrid;
	}

	/**
	 * 下载个人附件
	 * 
	 * @param id
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "downPersonFile")
	public void downPersonFile(String id, HttpServletResponse response)
			throws IOException {
		FileModel fileModel = new FileModel();
		fileModel.setId(id);
		fileModel = fileService.getFileModel(fileModel);
		String filename = COMMON.property("dir.upload")
				+ fileModel.getFilepath();

		File file = new File(filename);
		response.reset();

		// 取下载的文件名称
		String downfile = filename.substring(filename.lastIndexOf("/") + 1,
				filename.length());
		logger.info(downfile);
		logger.info(file.getName());

		response.addHeader("Content-Disposition", "attachment;filename="
				+ new String(file.getName().replace("("+fileModel.getId()+")", "").getBytes("gbk"), "iso-8859-1")); // 转码之后下载的文件不会出现中文乱码
		response.addHeader("Content-Length", "" + file.length());

		try {
			InputStream fis = new BufferedInputStream(new FileInputStream(
					filename));
			byte[] buffer = new byte[fis.available()];
			fis.read(buffer);
			fis.close();

			OutputStream toClient = new BufferedOutputStream(
					response.getOutputStream());
			toClient.write(buffer);
			toClient.flush();
			toClient.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
