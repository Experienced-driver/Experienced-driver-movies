/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  上午10:08:24
 *@desc:
 */
package com.hwadee.tb.file.domain;

import java.io.Serializable;

/**
 * @author xiangping
 *
 */
public class PageHelp implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int page;// 当前页
	private int rows;// 每页显示记录数
	private String sort;// 排序字段
	private String order;// asc/desc

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
