/**
 * <p>版权所有：四川华迪</p>
 *@author:xiangping
 *@date:2014年8月7日  上午10:09:27
 *@desc:
 */
package com.hwadee.tb.file.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author xiangping
 *
 */
@SuppressWarnings("rawtypes")
public class DataGrid implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long total = 0L;

	private List rows = new ArrayList();

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public List getRows() {
		return rows;
	}

	public void setRows(List rows) {
		this.rows = rows;
	}

}
