package com.hwadee.tb.base.persistence;

import com.hwadee.tb.base.domain.Bxtj;
import com.hwadee.tb.base.domain.Gjhz;
import com.hwadee.tb.base.domain.Xqhz;
import com.hwadee.tb.base.domain.Zjcyxx;
import com.hwadee.tb.base.domain.Zykcjs;

public interface BaseMapper {
	
	Bxtj getBxtjByAccountId(int accountId);
	void insertBxtj(Bxtj bxtj);
	void updateBxtj(Bxtj bxtj);
	
	Zykcjs getZykcjsByAccountId(int accountId);
	void insertZykcjs(Zykcjs zykcjs);
	void updateZykcjs(Zykcjs zykcjs);
	
	Gjhz getGjhzByAccountId(int accountId);
	void insertGjhz(Gjhz gjhz);
	void updateGjhz(Gjhz gjhz);
	
	Zjcyxx getZjcyxxByAccountId(int accountId);
	void insertZjcyxx(Zjcyxx zjcyxx);
	void updateZjcyxx(Zjcyxx zjcyxx);
	
	Xqhz getXqhzByAccountId(int accountId);
	void insertXqhz(Xqhz xqhz);
	void updateXqhz(Xqhz xqhz);
}
