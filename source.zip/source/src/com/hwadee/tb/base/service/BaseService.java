package com.hwadee.tb.base.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.base.domain.Bxtj;
import com.hwadee.tb.base.domain.Gjhz;
import com.hwadee.tb.base.domain.Xqhz;
import com.hwadee.tb.base.domain.Zjcyxx;
import com.hwadee.tb.base.domain.Zykcjs;
import com.hwadee.tb.base.persistence.BaseMapper;

@Service
public class BaseService {

	@Autowired
	private BaseMapper baseMapper;
	
	public Bxtj getBxtjByAccountId(int accountId) {
		return baseMapper.getBxtjByAccountId(accountId);
	}
	
	public void insertBxtj(Bxtj bxtj) {
		baseMapper.insertBxtj(bxtj);
	}
	
	public void updateBxtj(Bxtj bxtj) {
		baseMapper.updateBxtj(bxtj);
	}
	
	public Zykcjs getZykcjsByAccountId(int accountId) {
		return baseMapper.getZykcjsByAccountId(accountId);
	}
	
	public void insertZykcjs(Zykcjs zykcjs) {
		baseMapper.insertZykcjs(zykcjs);
	}
	
	public void updateZykcjs(Zykcjs zykcjs) {
		baseMapper.updateZykcjs(zykcjs);
	}
	
	public Gjhz getGjhzByAccountId(int accountId) {
		return baseMapper.getGjhzByAccountId(accountId);
	}
	
	public void insertGjhz(Gjhz gjhz) {
		baseMapper.insertGjhz(gjhz);
	}
	
	public void updateGjhz(Gjhz gjhz) {
		baseMapper.updateGjhz(gjhz);
	}
	
	public Zjcyxx getZjcyxxByAccountId(int accountId) {
		return baseMapper.getZjcyxxByAccountId(accountId);
	}
	
	public void insertZjcyxx(Zjcyxx zjcyxx) {
		baseMapper.insertZjcyxx(zjcyxx);
	}
	
	public void updateZjcyxx(Zjcyxx zjcyxx) {
		baseMapper.updateZjcyxx(zjcyxx);
	}
	
	public Xqhz getXqhzByAccountId(int accountId) {
		return baseMapper.getXqhzByAccountId(accountId);
	}
	
	public void insertXqhz(Xqhz xqhz) {
		baseMapper.insertXqhz(xqhz);
	}
	
	public void updateXqhz(Xqhz xqhz) {
		baseMapper.updateXqhz(xqhz);
	}
}
