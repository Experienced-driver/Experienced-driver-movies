package com.hwadee.tb.base.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.base.domain.Bxtj;
import com.hwadee.tb.base.domain.Gjhz;
import com.hwadee.tb.base.domain.Xqhz;
import com.hwadee.tb.base.domain.Zjcyxx;
import com.hwadee.tb.base.domain.Zykcjs;
import com.hwadee.tb.base.service.BaseService;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
@RequestMapping("base")
public class BaseController extends AbstractController {
	// 日志
	private static Log log = LogFactory.getLog(BaseController.class);
	
	private static final String BXTJ_VIEW = "base/bxtj";
	private static final String ZYKCJS_VIEW = "base/zykcjs";
	private static final String GJHZ_VIEW = "base/gjhz";
	private static final String ZJCYXX_VIEW = "base/zjcyxx";
	private static final String XQHZ_VIEW = "base/xqhz";
	
	@Resource(name="baseService")
	private BaseService baseService;
	
	@RequestMapping(method=RequestMethod.GET, value="bxtj")
	ModelAndView bxtj(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, BXTJ_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Bxtj bxtj = baseService.getBxtjByAccountId(account.getId());
		
		if (null == bxtj) {
			bxtj = new Bxtj();
			bxtj.setAccount_id(account.getId());
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(bxtj);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("bxtj", bxtj);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="bxtj/{action}")
	ModelAndView bxtj_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Bxtj bxtj) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(bxtj);
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.insertBxtj(bxtj);
				resultInfo = "写入办学条件记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.updateBxtj(bxtj);;
				resultInfo = "更新办学条件记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "办学条件写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="zykcjs")
	ModelAndView zykcjs(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, ZYKCJS_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Zykcjs zykcjs = baseService.getZykcjsByAccountId(account.getId());
		
		if (null == zykcjs) {
			zykcjs = new Zykcjs();
			zykcjs.setAccount_id(account.getId());
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(zykcjs);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("zykcjs", zykcjs);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="zykcjs/{action}")
	ModelAndView zykcjs_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Zykcjs zykcjs) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(zykcjs);
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.insertZykcjs(zykcjs);
				resultInfo = "写入专业与课程建设记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.updateZykcjs(zykcjs);
				resultInfo = "更新专业与课程建设记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "专业与课程建设写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="gjhz")
	ModelAndView gjhz(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, GJHZ_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Gjhz gjhz = baseService.getGjhzByAccountId(account.getId());
		
		if (null == gjhz) {
			gjhz = new Gjhz();
			gjhz.setAccount_id(account.getId());
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(gjhz);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("gjhz", gjhz);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="gjhz/{action}")
	ModelAndView gjhz_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Gjhz gjhz) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(gjhz);
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.insertGjhz(gjhz);
				resultInfo = "写入国际合作记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.updateGjhz(gjhz);
				resultInfo = "更新国际合作记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "国际合作写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="zjcyxx")
	ModelAndView zjcyxx(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, ZJCYXX_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Zjcyxx zjcyxx = baseService.getZjcyxxByAccountId(account.getId());
		
		if (null == zjcyxx) {
			zjcyxx = new Zjcyxx();
			zjcyxx.setAccount_id(account.getId());
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(zjcyxx);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("zjcyxx", zjcyxx);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="zjcyxx/{action}")
	ModelAndView zjcyxx_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Zjcyxx zjcyxx) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(zjcyxx);
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.insertZjcyxx(zjcyxx);
				resultInfo = "写入参与职教集团情况记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.updateZjcyxx(zjcyxx);
				resultInfo = "更新参与职教集团情况记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "参与职教集团情况写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="xqhz")
	ModelAndView xqhz(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, HttpSession session) {
		ModelAndView mav = init(T, XQHZ_VIEW);
		boolean readonly = false;
		boolean isNew = false;
		
		Account account = (Account) session.getAttribute("account");
		Xqhz xqhz = baseService.getXqhzByAccountId(account.getId());
		
		if (null == xqhz) {
			xqhz = new Xqhz();
			xqhz.setAccount_id(account.getId());
			
			isNew = true;
		}
		else {
			readonly = true;
		}
		
		log.debug(xqhz);
		
		mav.addObject("readonly", readonly);
		mav.addObject("isNew", isNew);
		mav.addObject("xqhz", xqhz);
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="xqhz/{action}")
	ModelAndView xqhz_action(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			@PathVariable String action, @ModelAttribute Xqhz xqhz) {
		ModelAndView mav = init(T, null);
		
		boolean isFailure = false;
		String resultInfo = null;
		
		log.debug(xqhz);
		
		try {
			if (CONSTANT.INSERT_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.insertXqhz(xqhz);
				resultInfo = "写入校企合作记录成功";
			}
			
			if (CONSTANT.UPDATE_ACTION.equalsIgnoreCase(action.trim())) {
				baseService.updateXqhz(xqhz);
				resultInfo = "更新校企合作记录成功";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			isFailure = true;
			resultInfo = "校企合作写入或更新失败";
		}
		
		mav.addObject("resultInfo", resultInfo);
		mav.addObject("isFailure", isFailure);
		
		return mav;
	}

}
