package com.hwadee.tb.base.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Zjcyxx implements Serializable {

	private int id;
	private int leader_count; // 本校牵牛组织的职教集团数
	private int leader_enterprise_count; // 参加本校牵头的职教集团企业数
	private int leader_school_count; // 参加本校牵头的职教集团学校数
	private int leader_profession_count; // 参加本校牵头的职教集团的专业数
	private int join_count; // 本校参与的职教集团数
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLeader_count() {
		return leader_count;
	}

	public void setLeader_count(int leader_count) {
		this.leader_count = leader_count;
	}

	public int getLeader_enterprise_count() {
		return leader_enterprise_count;
	}

	public void setLeader_enterprise_count(int leader_enterprise_count) {
		this.leader_enterprise_count = leader_enterprise_count;
	}

	public int getLeader_school_count() {
		return leader_school_count;
	}

	public void setLeader_school_count(int leader_school_count) {
		this.leader_school_count = leader_school_count;
	}

	public int getLeader_profession_count() {
		return leader_profession_count;
	}

	public void setLeader_profession_count(int leader_profession_count) {
		this.leader_profession_count = leader_profession_count;
	}

	public int getJoin_count() {
		return join_count;
	}

	public void setJoin_count(int join_count) {
		this.join_count = join_count;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
