package com.hwadee.tb.base.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Zykcjs implements Serializable {

	private int id;
	private int profession_category; // 专业大类数
	private int profession_count; // 专业数
	private int profession_aspects; // 专业方向数
	private int profession_leaders; // 省部级以上示范（重点、骨干、特色）专业数
	private int profession_contest; // 学校开展技能大赛的专业数
	private int profession_double; // 双证书专业数
	private int profession_project; // 实现项目教学的专业课程数
	private int profession_enterprise; // 企业参与开发的专业课程数
	private int teacher_public_books; // 校本教材数
	private int teacher_books; // 教师主编并公开出版的教材数
	private int share_books; // 牵头开发国家共建共享计划课程数
	private int share_nation_books; // 参与开发国家共建共享课程数
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProfession_category() {
		return profession_category;
	}

	public void setProfession_category(int profession_category) {
		this.profession_category = profession_category;
	}

	public int getProfession_count() {
		return profession_count;
	}

	public void setProfession_count(int profession_count) {
		this.profession_count = profession_count;
	}

	public int getProfession_aspects() {
		return profession_aspects;
	}

	public void setProfession_aspects(int profession_aspects) {
		this.profession_aspects = profession_aspects;
	}

	public int getProfession_leaders() {
		return profession_leaders;
	}

	public void setProfession_leaders(int profession_leaders) {
		this.profession_leaders = profession_leaders;
	}

	public int getProfession_contest() {
		return profession_contest;
	}

	public void setProfession_contest(int profession_contest) {
		this.profession_contest = profession_contest;
	}

	public int getProfession_double() {
		return profession_double;
	}

	public void setProfession_double(int profession_double) {
		this.profession_double = profession_double;
	}

	public int getProfession_project() {
		return profession_project;
	}

	public void setProfession_project(int profession_project) {
		this.profession_project = profession_project;
	}

	public int getProfession_enterprise() {
		return profession_enterprise;
	}

	public void setProfession_enterprise(int profession_enterprise) {
		this.profession_enterprise = profession_enterprise;
	}

	public int getTeacher_public_books() {
		return teacher_public_books;
	}

	public void setTeacher_public_books(int teacher_public_books) {
		this.teacher_public_books = teacher_public_books;
	}

	public int getTeacher_books() {
		return teacher_books;
	}

	public void setTeacher_books(int teacher_books) {
		this.teacher_books = teacher_books;
	}

	public int getShare_books() {
		return share_books;
	}

	public void setShare_books(int share_books) {
		this.share_books = share_books;
	}

	public int getShare_nation_books() {
		return share_nation_books;
	}

	public void setShare_nation_books(int share_nation_books) {
		this.share_nation_books = share_nation_books;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
