package com.hwadee.tb.base.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Gjhz implements Serializable {

	private int id;
	private int profession_coop_count; // 合作专业数
	private int profession_coop_course; // 合作课程数
	private int student_total; // 培养学生数
	private int write_books; // 开发教材数
	private int international_contests; // 国际技能大赛获奖数
	private int foreign_students; // 接受外籍学生数
	private int abroad_students; // 出国就业学生数
	private int foreign_course; // 引进国外课程数
	private int international_certs; // 引进国际证书数
	private int foreign_teachers; // 聘任外教数
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProfession_coop_count() {
		return profession_coop_count;
	}

	public void setProfession_coop_count(int profession_coop_count) {
		this.profession_coop_count = profession_coop_count;
	}

	public int getProfession_coop_course() {
		return profession_coop_course;
	}

	public void setProfession_coop_course(int profession_coop_course) {
		this.profession_coop_course = profession_coop_course;
	}

	public int getStudent_total() {
		return student_total;
	}

	public void setStudent_total(int student_total) {
		this.student_total = student_total;
	}

	public int getWrite_books() {
		return write_books;
	}

	public void setWrite_books(int write_books) {
		this.write_books = write_books;
	}

	public int getInternational_contests() {
		return international_contests;
	}

	public void setInternational_contests(int international_contests) {
		this.international_contests = international_contests;
	}

	public int getForeign_students() {
		return foreign_students;
	}

	public void setForeign_students(int foreign_students) {
		this.foreign_students = foreign_students;
	}

	public int getAbroad_students() {
		return abroad_students;
	}

	public void setAbroad_students(int abroad_students) {
		this.abroad_students = abroad_students;
	}

	public int getForeign_course() {
		return foreign_course;
	}

	public void setForeign_course(int foreign_course) {
		this.foreign_course = foreign_course;
	}

	public int getInternational_certs() {
		return international_certs;
	}

	public void setInternational_certs(int international_certs) {
		this.international_certs = international_certs;
	}

	public int getForeign_teachers() {
		return foreign_teachers;
	}

	public void setForeign_teachers(int foreign_teachers) {
		this.foreign_teachers = foreign_teachers;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
