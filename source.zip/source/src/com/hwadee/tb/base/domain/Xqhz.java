package com.hwadee.tb.base.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Xqhz implements Serializable {

	private int id;
	private int practice_count; // 校外实训基地数
	private int coop_enterprise_count; // 签订合作协议的企业数
	private int coop_profession_count; // 签订合作协议的专业数
	private int coop_ent_pro_count; // 合作企业参与教学的专业数
	private int coop_ent_pro_teacher_count; // 合作企业参与教学教师数
	private int coop_course_count; // 合作企业参与教学课时数
	private int coop_ent_funds; // 合作企业投入资金总额
	private int coop_ent_into_funds; // 合作企业投入到帐资金
	private int coop_ent_device; // 合作企业投入设备总值
	private int coop_ent_practice_students; // 合作企业接受实训学生数（人月）
	private int coop_ent_practice2_students; // 合作企业接受学生顶岗实习学生数
	private int coop_ent_occu_students; // 合作企业接受就业学生数
	private int rd_with_ent_count; // 与企业共建研发中心数
	private int outer_teacher_base_count; // 校外教师培训基地数',
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPractice_count() {
		return practice_count;
	}

	public void setPractice_count(int practice_count) {
		this.practice_count = practice_count;
	}

	public int getCoop_enterprise_count() {
		return coop_enterprise_count;
	}

	public void setCoop_enterprise_count(int coop_enterprise_count) {
		this.coop_enterprise_count = coop_enterprise_count;
	}

	public int getCoop_profession_count() {
		return coop_profession_count;
	}

	public void setCoop_profession_count(int coop_profession_count) {
		this.coop_profession_count = coop_profession_count;
	}

	public int getCoop_ent_pro_count() {
		return coop_ent_pro_count;
	}

	public void setCoop_ent_pro_count(int coop_ent_pro_count) {
		this.coop_ent_pro_count = coop_ent_pro_count;
	}

	public int getCoop_ent_pro_teacher_count() {
		return coop_ent_pro_teacher_count;
	}

	public void setCoop_ent_pro_teacher_count(int coop_ent_pro_teacher_count) {
		this.coop_ent_pro_teacher_count = coop_ent_pro_teacher_count;
	}

	public int getCoop_course_count() {
		return coop_course_count;
	}

	public void setCoop_course_count(int coop_course_count) {
		this.coop_course_count = coop_course_count;
	}

	public int getCoop_ent_funds() {
		return coop_ent_funds;
	}

	public void setCoop_ent_funds(int coop_ent_funds) {
		this.coop_ent_funds = coop_ent_funds;
	}

	public int getCoop_ent_into_funds() {
		return coop_ent_into_funds;
	}

	public void setCoop_ent_into_funds(int coop_ent_into_funds) {
		this.coop_ent_into_funds = coop_ent_into_funds;
	}

	public int getCoop_ent_device() {
		return coop_ent_device;
	}

	public void setCoop_ent_device(int coop_ent_device) {
		this.coop_ent_device = coop_ent_device;
	}

	public int getCoop_ent_practice_students() {
		return coop_ent_practice_students;
	}

	public void setCoop_ent_practice_students(int coop_ent_practice_students) {
		this.coop_ent_practice_students = coop_ent_practice_students;
	}

	public int getCoop_ent_practice2_students() {
		return coop_ent_practice2_students;
	}

	public void setCoop_ent_practice2_students(int coop_ent_practice2_students) {
		this.coop_ent_practice2_students = coop_ent_practice2_students;
	}

	public int getCoop_ent_occu_students() {
		return coop_ent_occu_students;
	}

	public void setCoop_ent_occu_students(int coop_ent_occu_students) {
		this.coop_ent_occu_students = coop_ent_occu_students;
	}

	public int getRd_with_ent_count() {
		return rd_with_ent_count;
	}

	public void setRd_with_ent_count(int rd_with_ent_count) {
		this.rd_with_ent_count = rd_with_ent_count;
	}

	public int getOuter_teacher_base_count() {
		return outer_teacher_base_count;
	}

	public void setOuter_teacher_base_count(int outer_teacher_base_count) {
		this.outer_teacher_base_count = outer_teacher_base_count;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
