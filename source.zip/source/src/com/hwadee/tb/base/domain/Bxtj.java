package com.hwadee.tb.base.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Bxtj implements Serializable {

	private int id;
	private float area; // 占地面积
	private float area_own; // 自有产权占地面积
	private float area_primary; // 主校区自有占地面积
	private int area_rent; // 租用校区剩余租用年限
	private float building_area; // 总建筑面积
	private float building_area_own; // 学校自有产权建筑面积
	private float building_area_primary; // 主校区自有产权建筑面积
	private int building_area_rent; // 租用建筑的剩余租用年限
	private int classrooms; // 理论课教室数
	private int classrooms_practice; // 理实一体教室数
	private int beds; // 住宿床位数
	private int food_seats; // 学生用餐座位数
	private int library_books; // 图书馆藏书数量
	private int electronic_books; // 电子读物数量
	private int newspapaer_count; // 报纸订阅数
	private int magazine_count; // 期刊订阅数
	private int reading_room_seats; // 阅览室座位数
	private int electronic_seats; // 电子阅览室座位数
	private int teacher_computers; // 教师用台式机数量
	private int teacher_laptop; // 教师用笔记本数量
	private float budget_funds; // 地方生均预算内拨款标准
	private float finance_funds; // 地方财政专项拨款
	private float debt; // 负债总额
	private float loan; // 货款总额
	private float device_funds; // 教学仪器设备总值
	private int device_count; // 教学仪器设备总量
	private int account_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}

	public float getArea_own() {
		return area_own;
	}

	public void setArea_own(float area_own) {
		this.area_own = area_own;
	}

	public float getArea_primary() {
		return area_primary;
	}

	public void setArea_primary(float area_primary) {
		this.area_primary = area_primary;
	}

	public int getArea_rent() {
		return area_rent;
	}

	public void setArea_rent(int area_rent) {
		this.area_rent = area_rent;
	}

	public float getBuilding_area() {
		return building_area;
	}

	public void setBuilding_area(float building_area) {
		this.building_area = building_area;
	}

	public float getBuilding_area_own() {
		return building_area_own;
	}

	public void setBuilding_area_own(float building_area_own) {
		this.building_area_own = building_area_own;
	}

	public float getBuilding_area_primary() {
		return building_area_primary;
	}

	public void setBuilding_area_primary(float building_area_primary) {
		this.building_area_primary = building_area_primary;
	}

	public int getBuilding_area_rent() {
		return building_area_rent;
	}

	public void setBuilding_area_rent(int building_area_rent) {
		this.building_area_rent = building_area_rent;
	}

	public int getClassrooms() {
		return classrooms;
	}

	public void setClassrooms(int classrooms) {
		this.classrooms = classrooms;
	}

	public int getClassrooms_practice() {
		return classrooms_practice;
	}

	public void setClassrooms_practice(int classrooms_practice) {
		this.classrooms_practice = classrooms_practice;
	}

	public int getBeds() {
		return beds;
	}

	public void setBeds(int beds) {
		this.beds = beds;
	}

	public int getFood_seats() {
		return food_seats;
	}

	public void setFood_seats(int food_seats) {
		this.food_seats = food_seats;
	}

	public int getLibrary_books() {
		return library_books;
	}

	public void setLibrary_books(int library_books) {
		this.library_books = library_books;
	}

	public int getElectronic_books() {
		return electronic_books;
	}

	public void setElectronic_books(int electronic_books) {
		this.electronic_books = electronic_books;
	}

	public int getNewspapaer_count() {
		return newspapaer_count;
	}

	public void setNewspapaer_count(int newspapaer_count) {
		this.newspapaer_count = newspapaer_count;
	}

	public int getMagazine_count() {
		return magazine_count;
	}

	public void setMagazine_count(int magazine_count) {
		this.magazine_count = magazine_count;
	}

	public int getReading_room_seats() {
		return reading_room_seats;
	}

	public void setReading_room_seats(int reading_room_seats) {
		this.reading_room_seats = reading_room_seats;
	}

	public int getElectronic_seats() {
		return electronic_seats;
	}

	public void setElectronic_seats(int electronic_seats) {
		this.electronic_seats = electronic_seats;
	}

	public int getTeacher_computers() {
		return teacher_computers;
	}

	public void setTeacher_computers(int teacher_computers) {
		this.teacher_computers = teacher_computers;
	}

	public int getTeacher_laptop() {
		return teacher_laptop;
	}

	public void setTeacher_laptop(int teacher_laptop) {
		this.teacher_laptop = teacher_laptop;
	}

	public float getBudget_funds() {
		return budget_funds;
	}

	public void setBudget_funds(float budget_funds) {
		this.budget_funds = budget_funds;
	}

	public float getFinance_funds() {
		return finance_funds;
	}

	public void setFinance_funds(float finance_funds) {
		this.finance_funds = finance_funds;
	}

	public float getDebt() {
		return debt;
	}

	public void setDebt(float debt) {
		this.debt = debt;
	}

	public float getLoan() {
		return loan;
	}

	public void setLoan(float loan) {
		this.loan = loan;
	}

	public float getDevice_funds() {
		return device_funds;
	}

	public void setDevice_funds(float device_funds) {
		this.device_funds = device_funds;
	}

	public int getDevice_count() {
		return device_count;
	}

	public void setDevice_count(int device_count) {
		this.device_count = device_count;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
