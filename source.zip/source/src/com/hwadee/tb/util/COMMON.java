package com.hwadee.tb.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class COMMON {
	// 日志
	private static Log log = LogFactory.getLog(COMMON.class);

	/**
	 * encode iso to gb2312
	 * 
	 * @author 张忠宇
	 */
	public static String iso2gb2312(final String str) {
		log.debug("\n\n COMMON.iso2gb2312(final String " + str
				+ ") start running--------------------------------->\n\n");
		String gb2312 = "";
		if (str != null && !(str.trim().equals(""))) {
			try {
				gb2312 = new String(str.getBytes("ISO-8859-1"), "GB2312");
			} catch (UnsupportedEncodingException uee) {
				log.debug("\n\n COMMON.iso2gb2312 is UnsupportedEncodingException -------------------------->"
						+ uee + "\n\n");
			}
		}
		log.debug("\n\n COMMON.iso2gb2312(final String " + str
				+ ") ended-------------------------->gb2312:" + gb2312 + "\n\n");
		return gb2312;
	}

	/**
	 * encode iso to utf8
	 * 
	 * @author 张忠宇
	 */
	public static String iso2utf8(final String str) {
		log.debug("\n\n COMMON.iso2utf8(final String " + str
				+ ") start running--------------------------------->\n\n");
		String gb2312 = "";
		if (str != null && !(str.trim().equals(""))) {
			try {
				gb2312 = new String(str.getBytes("ISO-8859-1"), "UTF-8");
			} catch (UnsupportedEncodingException uee) {
				log.debug("\n\n COMMON.iso2utf8 is UnsupportedEncodingException -------------------------->"
						+ uee + "\n\n");
			}
		}
		log.debug("\n\n COMMON.iso2utf8(final String " + str
				+ ") ended-------------------------->gb2312:" + gb2312 + "\n\n");
		return gb2312;
	}

	/**
	 * encode utf8 to GBK
	 * 
	 * @author 张忠宇
	 */
	public static String utf2gbk(final String str) {
		log.debug("\n\n COMMON.utf2gbk(final String " + str
				+ ") start running--------------------------------->\n\n");
		String gb2312 = "";
		if (str != null && !(str.trim().equals(""))) {
			try {
				gb2312 = new String(str.getBytes("UTF-8"), "GBK");
			} catch (UnsupportedEncodingException uee) {
				log.debug("\n\n COMMON.utf2gbk is UnsupportedEncodingException -------------------------->"
						+ uee + "\n\n");
			}
		}
		log.debug("\n\n COMMON.utf2gbk(final String " + str
				+ ") ended-------------------------->gb2312:" + gb2312 + "\n\n");
		return gb2312;
	}

	/**
	 * 产生UUID
	 * 
	 * @author 张忠宇
	 */
	public static String UUID() {
		String uuid = java.util.UUID.randomUUID().toString();
		StringBuilder bf = new StringBuilder(32);
		for (int i = 0; i < uuid.length(); ++i) {
			char c = uuid.charAt(i);
			if (c != '-' && c != '_') {
				bf.append(c);
			}
		}
		return bf.toString();
	}

	/**
	 * 读取属性文件
	 * 
	 * @author 张忠宇
	 */
	public static String property(String key) {
		try {
			Properties props = new Properties();
			InputStream in = COMMON.class
					.getResourceAsStream("/util.properties");
			props.load(in);
			in.close();

			return props.getProperty(key);
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return null;
		}
	}

	/**
	 * ”输出详细日期时间
	 * 
	 * @author 张忠宇
	 */
	public final static SimpleDateFormat sdf = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");

	public static String get_time() {
		Date date = new Date();
		return sdf.format(date);
	}

	/**
	 * ”输出（4位）年（2位）月（2位）日
	 * 
	 * @author 张忠宇
	 */
	final static SimpleDateFormat sdf_ymd = new SimpleDateFormat("yyyyMMdd");

	public static String get_time_ymd() {
		Date date = new Date();
		return sdf_ymd.format(date);
	}
	
	
	public static String get_time_ymd(String strDate) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = sdf.parse(strDate);
		return sdf_ymd.format(date);
	}
	
	public static String get_pre_month() {
		Calendar curr = Calendar.getInstance();
		curr.set(Calendar.MONTH,curr.get(Calendar.MONTH)-1);
		Date date=curr.getTime();
		return sdf_ymd.format(date);
	}
	
	public static String get_next_month() {
		Calendar curr = Calendar.getInstance();
		curr.set(Calendar.MONTH,curr.get(Calendar.MONTH)+1);
		Date date=curr.getTime();
		return sdf_ymd.format(date);
	}

	
	public static String get_dealTime() {
		Calendar c = Calendar.getInstance();
        c.setTime(new Date());   //设置当前日期
        c.add(Calendar.DATE, 5); //日期加1
        Date date = c.getTime(); //结果
        
		return sdf_ymd.format(date);
	}
	
	/**
	 * 补全流水号3位
	 * 
	 * @author 张忠宇
	 */
	public static String left_pad(char c, int l, String s) {
		int cl = s.length();
		if (cl < l) {
			for (int i = 0; i < l - cl; i++) {
				s = c + s;
			}
		}

		return s;
	}

	/**
	 * 将日期转换成 年月日的时间 yyyy-mm-dd
	 * 
	 * @param date
	 * @return date yyyy-mm-dd
	 * 
	 * @author 张忠宇
	 */
	public static String changeDateToYMD(String date) {

		if (date == null) {

			return null;
		}

		if (date.length() > 15) {
			try {
				String[] tt = date.split("\\.");
				return tt[0];
			} catch (Exception e) {

				return "0000-00-00";
			}
		} else if (date.length() <= 10) {

			return date;
		}

		return "0000-00-00";
	}

	/**
	 * 将yyyy-mm-dd hh24:mm:ss时间格式转化成 yyyy-mm-dd格式
	 * 
	 * @author 张忠宇
	 * */

	public static String changeDateToYYYY_MM_DD(String date) {

		String dataStr = date.substring(0, 10);

		return dataStr;
	}

	/**
	 * 产生预报申请号和业务流水号 自增序列
	 * 
	 * @string
	 * @author 张忠宇
	 * */
	public static String getFlowNumber(String flowStr) {
		// flowStr = "P20110302121";
		try {
			String flowNum = "";
			String currentDate = get_time_ymd();
			if (flowStr == "" || flowStr == null) {
				flowNum = currentDate + "001";
				return flowNum;
			}
			String strNum = flowStr.substring(1, flowStr.length());
			String beginStrNum = strNum.substring(0, 8);
			String endStrNum = strNum.substring(8, strNum.length());
			if (beginStrNum.equals(currentDate)) {
				flowNum = beginStrNum
						+ left_pad('0', 3, (Integer.parseInt(endStrNum) + 1)
								+ "");
			} else {
				flowNum = currentDate + "001";
			}
			log.debug("产生随机号:" + flowNum);
			return flowNum;
		} catch (Exception e) {
			log.debug("输入的随机号有错误");
		}

		return null;
	}

	/**
	 * 判断是否包含某个词语
	 * 
	 * @string
	 * @author 张忠宇
	 * */
	public static int strSearch(String str, String child) {
		String noChild = str.replace(child, "");
		return (str.length() - noChild.length()) / child.length();
	}

	/**
	 * 得到服务根路径
	 * 
	 * @HttpServletRequest 页面Request
	 * @author 蒲春灵
	 * */
	public static String getBasePath(HttpServletRequest request) {
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + path + "/";
		return basePath;
	}
	/**
	 * 得到文件后缀(包含.)
	 * 
	 * @author 蒲春灵
	 * */
	public static String getSuffix(String fileName) {
		String suffix = "";
		if (fileName.length() > 0) {
			suffix = fileName.substring(fileName.lastIndexOf("."));
		}
		return suffix;
	}

	/**
	 * ”输出（4位）年（2位）月（2位）日 () 小时() 分() 秒()
	 * 
	 * @author 林家纬
	 */
	final static SimpleDateFormat sdf_ymdhms = new SimpleDateFormat(
			"yyyyMMddHHmmss");

	public static String get_time_ymdhms() {
		Date date = new Date();
		return sdf_ymdhms.format(date);
	}
}
