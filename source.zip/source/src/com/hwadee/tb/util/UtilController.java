package com.hwadee.tb.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;

@Controller
@RequestMapping("common")
public class UtilController extends AbstractController {
	
	private static final long serialVersionUID = 8577449115373242476L;
	// 日志
	private static Log log = LogFactory.getLog(UtilController.class);

	static final String FAILURE_VIEW = "common/failure";

	@RequestMapping(method = RequestMethod.GET, value = "/failure")
	ModelAndView failure(@RequestParam(value = "T", defaultValue = CONSTANT.PERSON_COMPUTER) String T, 
			HttpServletRequest request) {
		ModelAndView mav = init(T, FAILURE_VIEW);
		log.debug("\n\n UtilController------------------> " + request.getRequestURL() + " \n\n");
		
		return mav;
	}

}
