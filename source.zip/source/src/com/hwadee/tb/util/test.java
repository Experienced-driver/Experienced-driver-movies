package com.hwadee.tb.util;

import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		int m,n,k;
		for (int i=100; i < 999; i++) {
			m = i/100;
			n = i/10%10;
			k = i%10;
			
			if (m*m*m + n*n*n + k*k*k == i)
				System.out.println(i);
				
		}
	}

}
