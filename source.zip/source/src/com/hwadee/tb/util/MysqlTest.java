package com.hwadee.tb.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MysqlTest {

	public static void main(String[] args) {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/tbxt";
		String user = "tbxt";
		String password = "tbxt";

		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user, password);

			if (!conn.isClosed())
				System.out.println("Succeeded connecting to the Database!");
			
			Statement statement = conn.createStatement();
			
			String sql = "SELECT count(*) as ccc FROM t_account";
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				System.out.print(rs.getInt("ccc"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
