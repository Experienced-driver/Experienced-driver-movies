﻿package com.hwadee.tb.util;


public class CONSTANT {
	
	// 终端（定义者：张忠宇）
	public static final String MOBILE_TERMINAL = "MT";
	public static final String PERSON_COMPUTER = "PC";
	public static final int PAGE_CAPACITY = Integer.parseInt(COMMON.property("page.capacity"));
	
	// SESSION（定义者：张忠宇）
	public static final String OUTSIDE_SESSION = COMMON.property("outside.session");
	public static final String PROJECT_URI = COMMON.property("prj.uri");
	public static final String PROJECT_REGISTER_URI = COMMON.property("prj.register.uri");
	public static final String PROJECT_SIGN_URI = COMMON.property("prj.sign.uri");
	public static final String PROJECT_RES_URI = COMMON.property("prj.res.uri");
	public static final String PROJECT_PAGE_URI = COMMON.property("prj.page.uri");
	
	// 文件上传（定义者：张忠宇）
	public static final String UPLOAD_DIR = COMMON.property("dir.upload");
	public static final long UPLOAD_SIZE = Long.valueOf(COMMON.property("file.upload.size"));
	public static final long IMAGE_UPLOAD_DIR = Long.valueOf(COMMON.property("image.upload.size"));
	public static final String FILE_UPLOAD_DIR = COMMON.property("dir.upload.file");
	public static final String IMG_UPLOAD_DIR = COMMON.property("dir.upload.img");
	
	// form action
	public static final String INSERT_ACTION = "insert";
	public static final String UPDATE_ACTION = "update";
  	
}
