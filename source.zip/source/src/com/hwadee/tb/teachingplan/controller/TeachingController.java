package com.hwadee.tb.teachingplan.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.hwadee.ssp.core.controller.AbstractController;
import com.hwadee.tb.sign.domain.Account;
import com.hwadee.tb.teacher.service.TeacherService;
import com.hwadee.tb.teachingplan.domain.Classhour;
import com.hwadee.tb.teachingplan.domain.Teachingplan;
import com.hwadee.tb.teachingplan.service.TeachingplanService;
import com.hwadee.tb.train.service.TrainService;
import com.hwadee.tb.util.COMMON;
import com.hwadee.tb.util.CONSTANT;

@SuppressWarnings("serial")
@Controller
@RequestMapping("teachingplan")
public class TeachingController extends AbstractController {

	// 日志
	private static Log log = LogFactory.getLog(TeachingController.class);
	
	private static final String TEACHINGPLAN = "teachingplan/teachingplan";
	
	private static final String EDITTEACHINGPLAN_VIEW = "teachingplan/editteachingplan";
	
	private static final String TEACHINGPLAN_VIEW = "teachingplan/teachingplanview";
	
	@Resource(name="teachingplanService")
	private TeachingplanService teachingplanService;
	
	@Resource(name="teacherService")
	private TeacherService teacherService;
	
	@Resource(name="trainService")
	private TrainService trainService;
	
	@RequestMapping(method=RequestMethod.GET, value="teachingplan")
	ModelAndView teachingplan(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			HttpSession session) {
		ModelAndView mav = init(T, TEACHINGPLAN);
		
		mav.addObject("professionallist", teacherService.getCourseList(2));
		mav.addObject("cgradelist", teacherService.getCourseList(3));
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="teachingplanview")
	ModelAndView teachingplanview(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			HttpSession session,@ModelAttribute Classhour classhour) {
		ModelAndView mav = init(T, TEACHINGPLAN_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		classhour.setAccount_id(account.getId());
		List<Classhour> classhourtable=teachingplanService.getClasshourlist(classhour);
		mav.addObject("classhourtable", classhourtable);
		
		Teachingplan teachingplan=new Teachingplan();
		teachingplan.setProfessional(classhour.getProfessional());
		teachingplan.setGrade(classhour.getGrade());
		teachingplan.setAccount_id(account.getId());
		Teachingplan oldteachingplan=teachingplanService.getTeachingplan(teachingplan);
		mav.addObject("teachingplan", oldteachingplan);
		
		mav.addObject("trainList", trainService.getTrainListByAccountId(account.getId()));
		
		return mav;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="editteachingplan")
	ModelAndView editteachingplan(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T, 
			HttpSession session,@ModelAttribute Classhour classhour) {
		ModelAndView mav = init(T, EDITTEACHINGPLAN_VIEW);
		
		Account account = (Account) session.getAttribute("account");
		classhour.setAccount_id(account.getId());
		List<Classhour> classhourtable=teachingplanService.getClasshourlist(classhour);
		mav.addObject("classhourtable", classhourtable);
		
		Teachingplan teachingplan=new Teachingplan();
		teachingplan.setProfessional(classhour.getProfessional());
		teachingplan.setGrade(classhour.getGrade());
		teachingplan.setAccount_id(account.getId());
		Teachingplan oldteachingplan=teachingplanService.getTeachingplan(teachingplan);
		mav.addObject("teachingplan", oldteachingplan);
		
		mav.addObject("trainList", trainService.getTrainListByAccountId(account.getId()));
		
		return mav;
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="addclasshourform")
	ModelAndView addclasshourform(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T,HttpSession session,@ModelAttribute Classhour classhour,@RequestParam Boolean isadd) {
		
		ModelAndView mav = init(T, null);
		
		Account account = (Account) session.getAttribute("account");
		classhour.setAccount_id(account.getId());
		String suffinfo="";
		
		if(isadd==true){
			
			teachingplanService.insertClasshour(classhour);
			
			String outdoc="<tr><td>"+classhour.getCourse_name()+"</td><td>"+classhour.getOpening_period()+"</td><td>"+classhour.getClass_number()+"</td></tr>";
			String optiondoc="<option value='"+classhour.getId()+"-"+classhour.getOpening_period()+"-"+classhour.getClass_number()+"'>"+classhour.getCourse_name()+"</option>";
			
			suffinfo="添加计划成功";
			
			mav.addObject("outdoc",outdoc);
			mav.addObject("optiondoc",optiondoc);
		}else{
			teachingplanService.updateClasshour(classhour);
			suffinfo="修订成功";
		}
		
		mav.addObject("suffinfo",suffinfo);
		return mav;
		
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="addTeachingplan")
	ModelAndView addTeachingplan(@RequestParam(value="T", defaultValue=CONSTANT.PERSON_COMPUTER) String T,HttpSession session,@ModelAttribute Teachingplan teachingplan,@RequestParam("enterprise_persons") MultipartFile file) {
		
		ModelAndView mav = init(T, null);
		
		String fileName = file.getOriginalFilename();
		if (!file.isEmpty() && file.getSize() <Integer.parseInt(COMMON.property("file.upload.size"))) {
			//上传地址
			String dirPath = COMMON.property("dir.upload.file");
			File dir = new File(dirPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			String excelPath = dirPath + fileName;
			teachingplan.setFile_name(fileName);
			teachingplan.setFile_name_path(excelPath);
			log.debug("\n\n excelUpload-----------"+ excelPath +"------->\n\n");
			
			byte[] bytes;
			try {
				bytes = file.getBytes();
				FileOutputStream fos = new FileOutputStream(new File(excelPath));
				fos.write(bytes);
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		if(teachingplan.getId()==0){
			teachingplanService.insertTeachingplan(teachingplan);
		}else{
			teachingplanService.updateTeachingplan(teachingplan);
		}
		
		return mav;
	}
	
}
