package com.hwadee.tb.teachingplan.persistence;

import java.util.List;

import com.hwadee.tb.teachingplan.domain.Classhour;
import com.hwadee.tb.teachingplan.domain.Teachingplan;

public interface TeachingplanMapper {
	
	void insertClasshour(Classhour classhour);
	void updateClasshour(Classhour classhour);
	List<Classhour> getClasshourlist(Classhour classhour);
	
	
	void insertTeachingplan(Teachingplan teachingplan);
	void updateTeachingplan(Teachingplan teachingplan);
	Teachingplan getTeachingplan(Teachingplan teachingplan);
}
