package com.hwadee.tb.teachingplan.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Classhour implements Serializable{

	private int id;
	
	private int professional; //专业
	
	private int grade; //年级
	
	private String course_name; //课程名称
	
	private int opening_period; //开设期数
	
	private int r_openingperiod; //修订开设期数
	
	private int class_number; //每期课时数
	
	private int r_classnumber; //修订每期课时数
	
	private int account_id;

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProfessional() {
		return professional;
	}

	public void setProfessional(int professional) {
		this.professional = professional;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public int getOpening_period() {
		return opening_period;
	}

	public void setOpening_period(int opening_period) {
		this.opening_period = opening_period;
	}

	public int getR_openingperiod() {
		return r_openingperiod;
	}

	public void setR_openingperiod(int r_openingperiod) {
		this.r_openingperiod = r_openingperiod;
	}

	public int getClass_number() {
		return class_number;
	}

	public void setClass_number(int class_number) {
		this.class_number = class_number;
	}

	public int getR_classnumber() {
		return r_classnumber;
	}

	public void setR_classnumber(int r_classnumber) {
		this.r_classnumber = r_classnumber;
	}
	
}
