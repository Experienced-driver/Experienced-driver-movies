package com.hwadee.tb.teachingplan.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Teachingplan implements Serializable{

	private int id;
	
	private int professional; //专业
	
	private int grade; //年级
	
	private String file_name; 	//专业教学计划（上传文档）
	
	private String file_name_path; 	//上传路径
	
	private String course_type;	//课程类型（理论或实训）
	
	private int training_room; //实训室使用（选择相应的实训室）
	
	private int out_schooltrain; //校外实训选择实训基地
	
	private int account_id;

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public String getFile_name_path() {
		return file_name_path;
	}

	public void setFile_name_path(String file_name_path) {
		this.file_name_path = file_name_path;
	}

	public int getProfessional() {
		return professional;
	}

	public void setProfessional(int professional) {
		this.professional = professional;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getCourse_type() {
		return course_type;
	}

	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}

	public int getTraining_room() {
		return training_room;
	}

	public void setTraining_room(int training_room) {
		this.training_room = training_room;
	}

	public int getOut_schooltrain() {
		return out_schooltrain;
	}

	public void setOut_schooltrain(int out_schooltrain) {
		this.out_schooltrain = out_schooltrain;
	}
	
}
