package com.hwadee.tb.teachingplan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.tb.teachingplan.domain.Classhour;
import com.hwadee.tb.teachingplan.domain.Teachingplan;
import com.hwadee.tb.teachingplan.persistence.TeachingplanMapper;

@Service
public class TeachingplanService {

	@Autowired
	private TeachingplanMapper teachingplanMapper;

	public void insertClasshour(Classhour classhour){
		teachingplanMapper.insertClasshour(classhour);
	}
	
	public List<Classhour> getClasshourlist(Classhour classhour){
		return teachingplanMapper.getClasshourlist(classhour);
	}
	
	public 	void updateClasshour(Classhour classhour){
		teachingplanMapper.updateClasshour(classhour);
	}
	
	public void insertTeachingplan(Teachingplan teachingplan){
		teachingplanMapper.insertTeachingplan(teachingplan);
	}
	
	public Teachingplan getTeachingplan(Teachingplan teachingplan){
		return teachingplanMapper.getTeachingplan(teachingplan);
	}
	
	public void updateTeachingplan(Teachingplan teachingplan){
		 teachingplanMapper.updateTeachingplan(teachingplan);
	}
}
