<?php
return array (
  'USER_INDEXADMIN_BAN' => '拉黑会员',
  'USER_INDEXADMIN_CANCELBAN' => '启用会员',
  'USER_INDEXADMIN_DEFAULT1' => 'User Group',
  'USER_INDEXADMIN_DEFAULT3' => 'Admin Group',
  'USER_INDEXADMIN_INDEX' => 'Site Users',
  'USER_OAUTHADMIN_DELETE' => '第三方用户解绑',
  'USER_OAUTHADMIN_INDEX' => 'Third Party Users',
  'USER_INDEXADMIN_DEFAULT' => 'Users',
);