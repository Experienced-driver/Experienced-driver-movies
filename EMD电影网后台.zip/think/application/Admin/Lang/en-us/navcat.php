<?php
return array(
		"NAME" => 'Name',
		"DESCRIPTION" => 'Description',
		"MAIN_NAVCAT" => 'Main Menu',
		"CATEGORY_NAME" => 'Category Name',
);