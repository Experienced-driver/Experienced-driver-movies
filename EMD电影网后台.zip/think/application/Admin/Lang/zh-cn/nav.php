<?php
return array(
		"NAVIGATION_NAME" => '菜单名称',
		'ADD_SUB_NAV' => '添加子菜单',
		"DISPLAY" => '显示',
		"HIDDEN" => '隐藏',
		"NAVIGATION_CATEGORY" => '菜单分类',
		"PARENT" => "父级",
		"LABEL" => '标签',
		"HREF" => '链接',
		"TARGET" => '打开方式',
		"TARGET_DEFAULT" => '默认',
		"TARGET_BLANK" =>'新窗口打开',
		"ICON" => '图标'
);