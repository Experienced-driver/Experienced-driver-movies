<?php
return array(
		"NICENAME" => '昵称',
		'GENDER' => '性别',
		"BIRTHDAY" => '生日',
		"WEBSITE" => '个人网址',
		"SIGNATURE" => '个性签名',
		"SAVE" => '保存',
		"FEMALE" => "女",
		"MALE" => "男",
		"GENDER_SECRECY" => '保密',
		"USERNAME" => '用户名',
		"EMAIL" => '邮箱',
		"ROLE" => '角色',
		"LAST_LOGIN_TIME" => "最后登录时间",
		"LAST_LOGIN_IP" => '最后登录IP',
		"STATUS" => '状态',
		"ACTIONS" => "操作",
		"USER_STATUS_BLOCKED" => '已拉黑',
		"USER_STATUS_ACTIVATED" => '正常',
		"USER_STATUS_UNVERIFIED" => '未验证',
		"BLOCK_USER" =>'拉黑',
		"BLOCK_USER_CONFIRM_MESSAGE" =>'您确定要拉黑此用户吗？',
		"ACTIVATE_USER" =>'启用',
		"ACTIVATE_USER_CONFIRM_MESSAGE" =>'您确定要启用此用户吗？',
		"USER_HAVENOT_LOGIN" => '该用户还没登陆过'
		
);